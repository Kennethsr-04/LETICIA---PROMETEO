
-- 1) Fix search_path on trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- 2) Revoke EXECUTE on SECURITY DEFINER functions from public/anon/authenticated.
-- They are still callable inside RLS policies (which run as the definer).
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_direccion(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.current_codigo_persona() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Allow server functions (running as authenticated user) to still call is_direccion via RPC
-- by granting EXECUTE only to authenticated for the two helpers our app code calls.
GRANT EXECUTE ON FUNCTION public.is_direccion(uuid) TO authenticated;

-- 3) ingestas INSERT: solo dirección
DROP POLICY IF EXISTS "ingestas_insert" ON public.ingestas;
CREATE POLICY "ingestas_insert_direccion" ON public.ingestas
  FOR INSERT TO authenticated
  WITH CHECK (public.is_direccion(auth.uid()));

-- 4) licitaciones INSERT: solo dirección (la app inserta solo durante ingesta)
DROP POLICY IF EXISTS "licitaciones_write_authenticated" ON public.licitaciones;
CREATE POLICY "licitaciones_insert_direccion" ON public.licitaciones
  FOR INSERT TO authenticated
  WITH CHECK (public.is_direccion(auth.uid()));

-- 5) licitaciones UPDATE: añadir WITH CHECK para evitar que comercial reasigne
DROP POLICY IF EXISTS "licitaciones_update_authenticated" ON public.licitaciones;
CREATE POLICY "licitaciones_update_authenticated" ON public.licitaciones
  FOR UPDATE TO authenticated
  USING (
    public.is_direccion(auth.uid())
    OR asignado_persona_id IS NULL
    OR asignado_persona_id = public.current_codigo_persona()
  )
  WITH CHECK (
    public.is_direccion(auth.uid())
    OR asignado_persona_id = public.current_codigo_persona()
  );

-- 6) anuncios INSERT: solo dirección
DROP POLICY IF EXISTS "anuncios_insert" ON public.anuncios;
CREATE POLICY "anuncios_insert_direccion" ON public.anuncios
  FOR INSERT TO authenticated
  WITH CHECK (public.is_direccion(auth.uid()));

-- 7) cpvs INSERT: solo dirección
DROP POLICY IF EXISTS "cpvs_write_authenticated" ON public.cpvs;
CREATE POLICY "cpvs_insert_direccion" ON public.cpvs
  FOR INSERT TO authenticated
  WITH CHECK (public.is_direccion(auth.uid()));

-- 8) licitacion_cpvs: separar lectura (auth) y escritura (dirección)
DROP POLICY IF EXISTS "licitacion_cpvs_all" ON public.licitacion_cpvs;
CREATE POLICY "licitacion_cpvs_read" ON public.licitacion_cpvs
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "licitacion_cpvs_write_direccion" ON public.licitacion_cpvs
  FOR INSERT TO authenticated WITH CHECK (public.is_direccion(auth.uid()));
CREATE POLICY "licitacion_cpvs_update_direccion" ON public.licitacion_cpvs
  FOR UPDATE TO authenticated
  USING (public.is_direccion(auth.uid()))
  WITH CHECK (public.is_direccion(auth.uid()));
CREATE POLICY "licitacion_cpvs_delete_direccion" ON public.licitacion_cpvs
  FOR DELETE TO authenticated USING (public.is_direccion(auth.uid()));

-- 9) licitacion_tags: lectura auth; escritura para quien pueda actualizar la licitación
DROP POLICY IF EXISTS "licitacion_tags_all" ON public.licitacion_tags;
CREATE POLICY "licitacion_tags_read" ON public.licitacion_tags
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "licitacion_tags_write" ON public.licitacion_tags
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.licitaciones l
      WHERE l.id = licitacion_id
        AND (
          public.is_direccion(auth.uid())
          OR l.asignado_persona_id IS NULL
          OR l.asignado_persona_id = public.current_codigo_persona()
        )
    )
  );
CREATE POLICY "licitacion_tags_delete" ON public.licitacion_tags
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.licitaciones l
      WHERE l.id = licitacion_id
        AND (
          public.is_direccion(auth.uid())
          OR l.asignado_persona_id = public.current_codigo_persona()
        )
    )
  );
