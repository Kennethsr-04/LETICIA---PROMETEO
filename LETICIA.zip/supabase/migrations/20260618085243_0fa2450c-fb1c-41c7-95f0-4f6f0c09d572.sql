
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('direccion', 'comercial');
CREATE TYPE public.etapa_licitacion AS ENUM ('previo', 'licitacion', 'evaluacion', 'cancelada');
CREATE TYPE public.bandeja AS ENUM ('R', 'E', 'P', 'L');
CREATE TYPE public.estado_workflow AS ENUM (
  'pendiente',
  'descartada_manual',
  'descartada_auto',
  'evaluada',
  'descartada',
  'preparar',
  'presentada',
  'ganada',
  'perdida'
);

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL,
  codigo_persona INTEGER,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============ USER ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_direccion(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT public.has_role(_user_id, 'direccion'::public.app_role) $$;

CREATE OR REPLACE FUNCTION public.current_codigo_persona()
RETURNS INTEGER LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT codigo_persona FROM public.profiles WHERE id = auth.uid() $$;

-- Profile policies
CREATE POLICY "profiles_read_all_authenticated" ON public.profiles
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "profiles_self_update" ON public.profiles
  FOR UPDATE TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_direccion_all" ON public.profiles
  FOR ALL TO authenticated
  USING (public.is_direccion(auth.uid()))
  WITH CHECK (public.is_direccion(auth.uid()));

CREATE POLICY "user_roles_self_read" ON public.user_roles
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_direccion(auth.uid()));

-- ============ MAESTROS ============
CREATE TABLE public.personas (
  id INTEGER PRIMARY KEY,
  nombre TEXT NOT NULL,
  activo BOOLEAN NOT NULL DEFAULT TRUE
);
GRANT SELECT ON public.personas TO authenticated;
GRANT ALL ON public.personas TO service_role;
ALTER TABLE public.personas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "personas_read" ON public.personas FOR SELECT TO authenticated USING (true);
CREATE POLICY "personas_direccion_write" ON public.personas FOR ALL TO authenticated
  USING (public.is_direccion(auth.uid())) WITH CHECK (public.is_direccion(auth.uid()));

INSERT INTO public.personas (id, nombre) VALUES
  (0, 'Moises'), (5, 'Marta'), (6, 'Santiago'), (7, 'Carmen'), (8, 'Adriana');

CREATE TABLE public.empresas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo TEXT NOT NULL UNIQUE,
  nombre TEXT NOT NULL
);
GRANT SELECT ON public.empresas TO authenticated;
GRANT ALL ON public.empresas TO service_role;
ALTER TABLE public.empresas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "empresas_read" ON public.empresas FOR SELECT TO authenticated USING (true);
CREATE POLICY "empresas_direccion_write" ON public.empresas FOR ALL TO authenticated
  USING (public.is_direccion(auth.uid())) WITH CHECK (public.is_direccion(auth.uid()));

INSERT INTO public.empresas (codigo, nombre) VALUES ('P', 'P'), ('B', 'B'), ('N', 'N');

CREATE TABLE public.tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL UNIQUE
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tags TO authenticated;
GRANT ALL ON public.tags TO service_role;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tags_read" ON public.tags FOR SELECT TO authenticated USING (true);
CREATE POLICY "tags_direccion_write" ON public.tags FOR ALL TO authenticated
  USING (public.is_direccion(auth.uid())) WITH CHECK (public.is_direccion(auth.uid()));

CREATE TABLE public.cpvs (
  codigo TEXT PRIMARY KEY,
  descripcion TEXT
);
GRANT SELECT, INSERT, UPDATE ON public.cpvs TO authenticated;
GRANT ALL ON public.cpvs TO service_role;
ALTER TABLE public.cpvs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cpvs_read" ON public.cpvs FOR SELECT TO authenticated USING (true);
CREATE POLICY "cpvs_write_authenticated" ON public.cpvs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "cpvs_direccion_update" ON public.cpvs FOR UPDATE TO authenticated
  USING (public.is_direccion(auth.uid()));

-- ============ LICITACIONES ============
CREATE TABLE public.licitaciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  expediente TEXT,
  codigo_gestboes TEXT,
  descripcion TEXT,
  contrato TEXT,
  forma_adjudicacion TEXT,
  importe_euros NUMERIC,
  organismo TEXT,
  administracion TEXT,
  provincia TEXT,
  autonomia TEXT,
  poblacion TEXT,
  plazo_meses NUMERIC,
  prorroga_anios NUMERIC,
  fecha_limite TIMESTAMPTZ,
  fecha_orientativa TIMESTAMPTZ,
  fecha_publicacion DATE,
  enlace_anuncio TEXT,
  enlace_secundario TEXT,
  informacion TEXT,
  observaciones TEXT,
  etapa public.etapa_licitacion NOT NULL DEFAULT 'licitacion',
  bandeja public.bandeja NOT NULL DEFAULT 'R',
  estado_workflow public.estado_workflow NOT NULL DEFAULT 'pendiente',
  asignado_persona_id INTEGER REFERENCES public.personas(id),
  empresa_id UUID REFERENCES public.empresas(id),
  interes INTEGER CHECK (interes IS NULL OR (interes BETWEEN 1 AND 9)),
  evaluada BOOLEAN NOT NULL DEFAULT FALSE,
  comentarios_evaluacion TEXT,
  descartada BOOLEAN NOT NULL DEFAULT FALSE,
  motivo_descarte TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (expediente, codigo_gestboes)
);
CREATE INDEX idx_licitaciones_bandeja ON public.licitaciones(bandeja, estado_workflow);
CREATE INDEX idx_licitaciones_asignado ON public.licitaciones(asignado_persona_id);
CREATE INDEX idx_licitaciones_fecha_limite ON public.licitaciones(fecha_limite);
CREATE INDEX idx_licitaciones_etapa ON public.licitaciones(etapa);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.licitaciones TO authenticated;
GRANT ALL ON public.licitaciones TO service_role;
ALTER TABLE public.licitaciones ENABLE ROW LEVEL SECURITY;

-- Comerciales ven sus asignadas + sin asignar (bandeja R). Dirección ve todo.
CREATE POLICY "licitaciones_read" ON public.licitaciones FOR SELECT TO authenticated
  USING (
    public.is_direccion(auth.uid())
    OR asignado_persona_id IS NULL
    OR asignado_persona_id = public.current_codigo_persona()
  );
CREATE POLICY "licitaciones_write_authenticated" ON public.licitaciones FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "licitaciones_update_authenticated" ON public.licitaciones FOR UPDATE TO authenticated
  USING (
    public.is_direccion(auth.uid())
    OR asignado_persona_id IS NULL
    OR asignado_persona_id = public.current_codigo_persona()
  );
CREATE POLICY "licitaciones_delete_direccion" ON public.licitaciones FOR DELETE TO authenticated
  USING (public.is_direccion(auth.uid()));

-- ============ JOIN TABLES ============
CREATE TABLE public.licitacion_cpvs (
  licitacion_id UUID NOT NULL REFERENCES public.licitaciones(id) ON DELETE CASCADE,
  cpv_codigo TEXT NOT NULL REFERENCES public.cpvs(codigo) ON DELETE CASCADE,
  PRIMARY KEY (licitacion_id, cpv_codigo)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.licitacion_cpvs TO authenticated;
GRANT ALL ON public.licitacion_cpvs TO service_role;
ALTER TABLE public.licitacion_cpvs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "licitacion_cpvs_all" ON public.licitacion_cpvs FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.licitacion_tags (
  licitacion_id UUID NOT NULL REFERENCES public.licitaciones(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES public.tags(id) ON DELETE CASCADE,
  PRIMARY KEY (licitacion_id, tag_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.licitacion_tags TO authenticated;
GRANT ALL ON public.licitacion_tags TO service_role;
ALTER TABLE public.licitacion_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "licitacion_tags_all" ON public.licitacion_tags FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ============ ANUNCIOS ============
CREATE TABLE public.anuncios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  licitacion_id UUID NOT NULL REFERENCES public.licitaciones(id) ON DELETE CASCADE,
  fecha_publicacion DATE,
  etapa public.etapa_licitacion,
  estado_raw TEXT,
  importe_euros NUMERIC,
  descripcion TEXT,
  organismo TEXT,
  enlace_anuncio TEXT,
  fecha_limite TIMESTAMPTZ,
  fecha_orientativa TIMESTAMPTZ,
  forma_adjudicacion TEXT,
  raw_jsonb JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_anuncios_licitacion ON public.anuncios(licitacion_id);
GRANT SELECT, INSERT ON public.anuncios TO authenticated;
GRANT ALL ON public.anuncios TO service_role;
ALTER TABLE public.anuncios ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anuncios_read" ON public.anuncios FOR SELECT TO authenticated USING (true);
CREATE POLICY "anuncios_insert" ON public.anuncios FOR INSERT TO authenticated WITH CHECK (true);

-- ============ INGESTAS ============
CREATE TABLE public.ingestas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  filename TEXT NOT NULL,
  uploaded_by UUID REFERENCES auth.users(id),
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  total_filas INTEGER NOT NULL DEFAULT 0,
  nuevas_licitaciones INTEGER NOT NULL DEFAULT 0,
  licitaciones_actualizadas INTEGER NOT NULL DEFAULT 0,
  anuncios_anadidos INTEGER NOT NULL DEFAULT 0,
  errores JSONB
);
GRANT SELECT, INSERT ON public.ingestas TO authenticated;
GRANT ALL ON public.ingestas TO service_role;
ALTER TABLE public.ingestas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ingestas_direccion_read" ON public.ingestas FOR SELECT TO authenticated
  USING (public.is_direccion(auth.uid()) OR uploaded_by = auth.uid());
CREATE POLICY "ingestas_insert" ON public.ingestas FOR INSERT TO authenticated WITH CHECK (true);

-- ============ TRIGGERS ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_licitaciones_updated BEFORE UPDATE ON public.licitaciones
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, nombre)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'nombre', NEW.email));
  -- Default role: comercial
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'comercial');
  RETURN NEW;
END $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
