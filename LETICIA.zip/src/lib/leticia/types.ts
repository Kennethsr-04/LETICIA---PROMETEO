export type Bandeja = "R" | "E" | "P" | "L";
export type Etapa = "previo" | "licitacion" | "evaluacion" | "cancelada";
export type EstadoWorkflow =
  | "pendiente"
  | "descartada_manual"
  | "descartada_auto"
  | "evaluada"
  | "descartada"
  | "preparar"
  | "presentada"
  | "ganada"
  | "perdida";

export interface Persona {
  id: number;
  nombre: string;
  activo: boolean;
}

export interface Cpv {
  codigo: string;
  descripcion: string | null;
}

export interface Empresa {
  id: string;
  codigo: string;
  nombre: string;
}

export interface Tag {
  id: string;
  nombre: string;
}

export interface Licitacion {
  id: string;
  expediente: string | null;
  codigo_gestboes: string | null;
  descripcion: string | null;
  contrato: string | null;
  forma_adjudicacion: string | null;
  importe_euros: number | null;
  organismo: string | null;
  administracion: string | null;
  provincia: string | null;
  autonomia: string | null;
  poblacion: string | null;
  plazo_meses: number | null;
  prorroga_anios: number | null;
  fecha_limite: string | null;
  fecha_orientativa: string | null;
  fecha_publicacion: string | null;
  enlace_anuncio: string | null;
  enlace_secundario: string | null;
  informacion: string | null;
  observaciones: string | null;
  etapa: Etapa;
  bandeja: Bandeja;
  estado_workflow: EstadoWorkflow;
  asignado_persona_id: number | null;
  empresa_id: string | null;
  interes: number | null;
  evaluada: boolean;
  comentarios_evaluacion: string | null;
  descartada: boolean;
  motivo_descarte: string | null;
  created_at: string;
  updated_at: string;
  cpvs?: { codigo: string; descripcion: string | null }[];
  tags?: { id: string; nombre: string }[];
  persona?: Persona | null;
  empresa?: Empresa | null;
}

export interface Anuncio {
  id: string;
  licitacion_id: string;
  fecha_publicacion: string | null;
  etapa: Etapa | null;
  estado_raw: string | null;
  importe_euros: number | null;
  descripcion: string | null;
  organismo: string | null;
  enlace_anuncio: string | null;
  fecha_limite: string | null;
  fecha_orientativa: string | null;
  forma_adjudicacion: string | null;
  raw_jsonb: Record<string, unknown> | null;
  created_at: string;
}

export interface Ingesta {
  id: string;
  filename: string;
  uploaded_by: string | null;
  uploaded_at: string;
  total_filas: number;
  nuevas_licitaciones: number;
  licitaciones_actualizadas: number;
  anuncios_anadidos: number;
  errores: unknown;
}
