import { format } from "date-fns";
import { es } from "date-fns/locale";

export function formatEuros(n: number | null | undefined): string {
  if (n == null) return "—";
  return new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(n);
}

export function formatFechaCorta(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return format(new Date(iso), "dd/MM/yyyy", { locale: es });
  } catch {
    return "—";
  }
}

export function formatFechaHora(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return format(new Date(iso), "dd/MM/yyyy HH:mm", { locale: es });
  } catch {
    return "—";
  }
}

export function formatHora(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return format(new Date(iso), "HH:mm", { locale: es });
  } catch {
    return "—";
  }
}

export function shortId(id: string): string {
  return id.slice(0, 8);
}
