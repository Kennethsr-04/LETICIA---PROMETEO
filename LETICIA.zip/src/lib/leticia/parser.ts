import type { Etapa } from "./types";

// Helpers to parse Gestboes Excel rows.

export interface RawRow {
  [key: string]: unknown;
}

const norm = (v: unknown): string =>
  v == null ? "" : String(v).trim();

export function parseFechaLimite(raw: unknown): string | null {
  const s = norm(raw);
  if (!s) return null;
  // "Fecha límite de presentación de ofertas: 24/03/2026 a las 14:00 horas"
  const m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[^0-9]+(\d{1,2}):(\d{2}))?/);
  if (!m) return null;
  const [, dd, mm, yyyy, hh = "23", min = "59"] = m;
  const iso = `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}T${hh.padStart(2, "0")}:${min}:00`;
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;
  return d.toISOString();
}

export function parseFechaSimple(raw: unknown): string | null {
  if (raw == null || raw === "") return null;
  if (raw instanceof Date) return raw.toISOString();
  const s = norm(raw);
  // ISO?
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d.toISOString();
  }
  const m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (m) {
    const [, dd, mm, yyyy] = m;
    return new Date(`${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}T00:00:00`).toISOString();
  }
  return null;
}

export function parseImporte(raw: unknown): number | null {
  if (raw == null || raw === "") return null;
  if (typeof raw === "number") return raw;
  const s = norm(raw).replace(/\s/g, "").replace(/€/g, "");
  // 2.066.000,00 -> 2066000.00
  const normalized = s.includes(",")
    ? s.replace(/\./g, "").replace(",", ".")
    : s.replace(/(?<=\d)\.(?=\d{3}\b)/g, "");
  const n = Number(normalized);
  return isNaN(n) ? null : n;
}

export function parsePlazoMeses(raw: unknown): number | null {
  const s = norm(raw).toLowerCase();
  if (!s) return null;
  const m = s.match(/(\d+(?:[.,]\d+)?)\s*(mes|meses|año|años|day|día|días)/);
  if (!m) {
    const n = parseFloat(s.replace(",", "."));
    return isNaN(n) ? null : n;
  }
  const val = parseFloat(m[1].replace(",", "."));
  const unit = m[2];
  if (unit.startsWith("año")) return val * 12;
  if (unit.startsWith("día") || unit === "day") return val / 30;
  return val;
}

export function parseProrrogaAnios(raw: unknown): number | null {
  const s = norm(raw).toLowerCase();
  if (!s) return null;
  const m = s.match(/prorroga[^0-9]*(\d+(?:[.,]\d+)?)/i) || s.match(/(\d+(?:[.,]\d+)?)\s*año/);
  if (!m) return null;
  return parseFloat(m[1].replace(",", "."));
}

export function parseCpvs(raw: unknown): { codigo: string; descripcion: string | null }[] {
  const s = norm(raw);
  if (!s) return [];
  // Format examples: "72000000-5 Servicios TI" or multi-line "72000000\nDescription"
  const parts = s
    .split(/[\n;]/)
    .map((p) => p.trim())
    .filter(Boolean);
  return parts.map((p) => {
    const m = p.match(/^(\d{6,10}(?:-\d)?)\s*[-:\s]?\s*(.*)$/);
    if (m) return { codigo: m[1], descripcion: m[2] || null };
    return { codigo: p, descripcion: null };
  });
}

export function parseEnlaces(raw: unknown): { principal: string | null; secundario: string | null } {
  const s = norm(raw);
  if (!s) return { principal: null, secundario: null };
  const urls = s.match(/https?:\/\/[^\s]+/g) || [];
  return { principal: urls[0] || null, secundario: urls[1] || null };
}

export function clasificarEtapa(row: RawRow, fechaLimite: string | null, existePrevia: boolean): Etapa {
  const estado = norm(row["Estado"]).toLowerCase();
  if (/desist|cancel|anulad/.test(estado)) return "cancelada";

  const forma = norm(row["Forma de adjudicación"]).toLowerCase();
  const fechaOrient = norm(row["Fecha Orientativa Gestboes."]);
  const fechaLim = norm(row["Fecha Límite de Pesent."]);

  // Previo: forma incluye "previo/a" Y fecha orientativa vacía Y fecha límite vacía
  if (/\bprevio\b|\bprevia\b/.test(forma) && !fechaOrient && !fechaLim) {
    return "previo";
  }

  // Evaluacion: fecha límite vencida y existe licitación previa
  if (fechaLimite) {
    const fl = new Date(fechaLimite);
    if (fl < new Date() && existePrevia) return "evaluacion";
  }

  return "licitacion";
}
