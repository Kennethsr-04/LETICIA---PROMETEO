import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Bandeja, EstadoWorkflow } from "@/lib/leticia/types";

// --- LIST LICITACIONES ---
const listSchema = z.object({
  bandeja: z.enum(["R", "E", "P", "L"]),
  search: z.string().optional().default(""),
  estadosWorkflow: z.array(z.string()).optional(),
  etapas: z.array(z.string()).optional(),
  fechaDesde: z.string().optional().nullable(),
  fechaHasta: z.string().optional().nullable(),
  interes: z.array(z.number()).optional(),
  empresaId: z.string().optional().nullable(),
  personaId: z.number().optional().nullable(),
  importeMin: z.number().optional().nullable(),
  importeMax: z.number().optional().nullable(),
  tagIds: z.array(z.string()).optional(),
  orderBy: z.string().optional().default("fecha_limite"),
  orderDir: z.enum(["asc", "desc"]).optional().default("asc"),
});

export const listLicitaciones = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => listSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase
      .from("licitaciones")
      .select(
        `*,
        persona:personas(id,nombre,activo),
        empresa:empresas(id,codigo,nombre),
        cpvs:licitacion_cpvs(cpv:cpvs(codigo,descripcion)),
        tags:licitacion_tags(tag:tags(id,nombre))`,
      )
      .eq("bandeja", data.bandeja);

    if (data.estadosWorkflow && data.estadosWorkflow.length > 0) {
      q = q.in("estado_workflow", data.estadosWorkflow as never[]);
    }
    if (data.etapas && data.etapas.length > 0) {
      q = q.in("etapa", data.etapas as never[]);
    }
    if (data.fechaDesde) q = q.gte("fecha_limite", data.fechaDesde);
    if (data.fechaHasta) q = q.lte("fecha_limite", data.fechaHasta);
    if (data.interes && data.interes.length > 0) q = q.in("interes", data.interes);
    if (data.empresaId) q = q.eq("empresa_id", data.empresaId);
    if (data.personaId != null) q = q.eq("asignado_persona_id", data.personaId);
    if (data.importeMin != null) q = q.gte("importe_euros", data.importeMin);
    if (data.importeMax != null) q = q.lte("importe_euros", data.importeMax);
    if (data.search) {
      const s = `%${data.search}%`;
      q = q.or(
        `descripcion.ilike.${s},organismo.ilike.${s},expediente.ilike.${s},codigo_gestboes.ilike.${s},provincia.ilike.${s},forma_adjudicacion.ilike.${s}`,
      );
    }

    q = q.order(data.orderBy as never, { ascending: data.orderDir === "asc", nullsFirst: false });
    q = q.limit(500);

    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);

    // Flatten join shapes
    type CpvShape = { codigo: string; descripcion: string | null };
    type TagShape = { id: string; nombre: string };
    const result = (rows ?? []).map((r: Record<string, unknown>) => ({
      ...r,
      cpvs: ((r.cpvs as { cpv: CpvShape }[]) ?? [])
        .map((j) => j.cpv)
        .filter(Boolean) as CpvShape[],
      tags: ((r.tags as { tag: TagShape }[]) ?? [])
        .map((j) => j.tag)
        .filter(Boolean) as TagShape[],
    }));

    // Tag filter (in-memory)
    let filtered = result;
    if (data.tagIds && data.tagIds.length > 0) {
      const set = new Set(data.tagIds);
      filtered = filtered.filter((r) => r.tags.some((t) => set.has(t.id)));
    }
    return filtered;
  });

// --- GET LICITACION ---
export const getLicitacion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: lic, error } = await supabase
      .from("licitaciones")
      .select(
        `*,
        persona:personas(id,nombre,activo),
        empresa:empresas(id,codigo,nombre),
        cpvs:licitacion_cpvs(cpv:cpvs(codigo,descripcion)),
        tags:licitacion_tags(tag:tags(id,nombre))`,
      )
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!lic) throw new Error("Licitación no encontrada");

    const { data: anuncios } = await supabase
      .from("anuncios")
      .select("*")
      .eq("licitacion_id", data.id)
      .order("created_at", { ascending: false });

    type CpvShape = { codigo: string; descripcion: string | null };
    type TagShape = { id: string; nombre: string };
    return {
      licitacion: {
        ...lic,
        cpvs: ((lic.cpvs as { cpv: CpvShape }[]) ?? [])
          .map((j) => j.cpv)
          .filter(Boolean) as CpvShape[],
        tags: ((lic.tags as { tag: TagShape }[]) ?? [])
          .map((j) => j.tag)
          .filter(Boolean) as TagShape[],
      },
      anuncios: anuncios ?? [],
    };
  });

// --- UPDATE LICITACION ---
const updateSchema = z.object({
  id: z.string().uuid(),
  patch: z
    .object({
      asignado_persona_id: z.number().nullable().optional(),
      empresa_id: z.string().nullable().optional(),
      interes: z.number().min(1).max(9).nullable().optional(),
      evaluada: z.boolean().optional(),
      comentarios_evaluacion: z.string().nullable().optional(),
      descripcion: z.string().nullable().optional(),
      organismo: z.string().nullable().optional(),
      contrato: z.string().nullable().optional(),
      forma_adjudicacion: z.string().nullable().optional(),
      importe_euros: z.number().nullable().optional(),
      plazo_meses: z.number().nullable().optional(),
      prorroga_anios: z.number().nullable().optional(),
    })
    .passthrough(),
});

export const updateLicitacion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => updateSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase.from("licitaciones").update(data.patch as never).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// --- TRANSITION (asignar, descartar, evaluar, preparar, presentar, ganada, perdida) ---
const transitionSchema = z.object({
  id: z.string().uuid(),
  action: z.enum([
    "asignar",
    "descartar_R",
    "descartar_E",
    "descartar_P",
    "marcar_evaluada",
    "desmarcar_evaluada",
    "pasar_a_preparar",
    "pasar_a_licitada",
    "marcar_ganada",
    "marcar_perdida",
    "restaurar",
  ]),
  personaId: z.number().nullable().optional(),
});

export const transitionLicitacion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => transitionSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let patch: Record<string, unknown> = {};
    switch (data.action) {
      case "asignar":
        patch = {
          asignado_persona_id: data.personaId,
          bandeja: data.personaId != null ? "E" : "R",
          estado_workflow: data.personaId != null ? "pendiente" : "pendiente",
          descartada: false,
          motivo_descarte: null,
        };
        break;
      case "descartar_R":
        patch = {
          estado_workflow: "descartada_manual",
          descartada: true,
          motivo_descarte: "manual_R",
        };
        break;
      case "descartar_E":
        patch = { estado_workflow: "descartada", descartada: true, motivo_descarte: "manual_E" };
        break;
      case "descartar_P":
        patch = { estado_workflow: "descartada", descartada: true, motivo_descarte: "manual_P" };
        break;
      case "marcar_evaluada":
        patch = { evaluada: true, estado_workflow: "evaluada" };
        break;
      case "desmarcar_evaluada":
        patch = { evaluada: false, estado_workflow: "pendiente" };
        break;
      case "pasar_a_preparar":
        patch = { bandeja: "P", estado_workflow: "preparar", descartada: false, motivo_descarte: null };
        break;
      case "pasar_a_licitada":
        patch = { bandeja: "L", estado_workflow: "presentada", descartada: false, motivo_descarte: null };
        break;
      case "marcar_ganada":
        patch = { estado_workflow: "ganada" };
        break;
      case "marcar_perdida":
        patch = { estado_workflow: "perdida" };
        break;
      case "restaurar":
        patch = { descartada: false, motivo_descarte: null, estado_workflow: "pendiente" };
        break;
    }
    const { error } = await supabase.from("licitaciones").update(patch as never).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// --- AUTO RULES (auto-descarte por fecha vencida) ---
export const runAutoRules = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const nowIso = new Date().toISOString();

    // R/pendiente con fecha_limite vencida -> descartada_auto
    const { error: e1 } = await supabase
      .from("licitaciones")
      .update({ estado_workflow: "descartada_auto", descartada: true, motivo_descarte: "auto_fecha_R" })
      .eq("bandeja", "R")
      .eq("estado_workflow", "pendiente")
      .lt("fecha_limite", nowIso);
    if (e1) throw new Error(e1.message);

    // E/pendiente con fecha_limite vencida -> descartada
    const { error: e2 } = await supabase
      .from("licitaciones")
      .update({ estado_workflow: "descartada", descartada: true, motivo_descarte: "auto_fecha_E" })
      .eq("bandeja", "E")
      .eq("estado_workflow", "pendiente")
      .lt("fecha_limite", nowIso);
    if (e2) throw new Error(e2.message);

    return { ok: true };
  });

// --- COUNT BANDEJAS for sidebar badges ---
export const getBandejaCounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const bandejas: Bandeja[] = ["R", "E", "P", "L"];
    const counts: Record<Bandeja, number> = { R: 0, E: 0, P: 0, L: 0 };
    for (const b of bandejas) {
      const { count } = await supabase
        .from("licitaciones")
        .select("id", { count: "exact", head: true })
        .eq("bandeja", b)
        .eq("descartada", false);
      counts[b] = count ?? 0;
    }
    return counts;
  });
