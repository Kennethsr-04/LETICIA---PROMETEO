import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import * as XLSX from "xlsx";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  clasificarEtapa,
  parseCpvs,
  parseEnlaces,
  parseFechaLimite,
  parseFechaSimple,
  parseImporte,
  parsePlazoMeses,
  parseProrrogaAnios,
  type RawRow,
} from "@/lib/leticia/parser";

const ingestSchema = z.object({
  filename: z.string(),
  base64: z.string(),
});

const norm = (v: unknown) => (v == null ? null : String(v).trim() || null);

export const ingestExcelGestboes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ingestSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Solo dirección puede ingestar
    const { data: isDir, error: roleErr } = await supabase.rpc("is_direccion", { _user_id: userId });
    if (roleErr) throw new Error(roleErr.message);
    if (!isDir) throw new Error("Forbidden: solo dirección puede realizar ingestas");

    // Decode base64 -> Uint8Array
    const bin = atob(data.base64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);

    const wb = XLSX.read(buf, { type: "array", cellDates: true });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<RawRow>(sheet, { defval: null, raw: false });

    let nuevas = 0;
    let actualizadas = 0;
    let anuncios = 0;
    const errores: { fila: number; error: string }[] = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      try {
        const codigo = norm(row["Código"]);
        const expediente = norm(row["Expediente"]);
        if (!codigo || !expediente) {
          errores.push({ fila: i + 2, error: "Falta Código o Expediente" });
          continue;
        }

        const fechaLimite = parseFechaLimite(row["Fecha Límite de Pesent."]);
        const fechaOrientativa = parseFechaSimple(row["Fecha Orientativa Gestboes."]);
        const fechaPub = parseFechaSimple(row["Fecha"]);
        const enlaces = parseEnlaces(row["Enlace Anuncio"]);
        const enlaceInfo = parseEnlaces(row["Información"]);
        const cpvs = parseCpvs(row["CPV"]);
        const importe = parseImporte(row["Importe en Euros"]);

        // Buscar licitación existente
        const { data: existing, error: searchErr } = await supabase
          .from("licitaciones")
          .select("id, bandeja, estado_workflow, descartada")
          .eq("expediente", expediente)
          .eq("codigo_gestboes", codigo)
          .maybeSingle();
        if (searchErr) throw new Error(searchErr.message);

        const etapa = clasificarEtapa(row, fechaLimite, !!existing);
        const estadoRaw = norm(row["Estado"]);

        const licData = {
          expediente,
          codigo_gestboes: codigo,
          descripcion: norm(row["Descripción"]),
          contrato: norm(row["Contrato"]),
          forma_adjudicacion: norm(row["Forma de adjudicación"]),
          importe_euros: importe,
          organismo: norm(row["Organismo"]),
          administracion: norm(row["Administración"]),
          provincia: norm(row["Provincia"]),
          autonomia: norm(row["Autonomía"]),
          poblacion: norm(row["Población"]),
          plazo_meses: parsePlazoMeses(row["Plazo Ejecución"]),
          prorroga_anios: parseProrrogaAnios(row["Observaciones"]) ?? parseProrrogaAnios(row["Licitación"]),
          fecha_limite: fechaLimite,
          fecha_orientativa: fechaOrientativa,
          fecha_publicacion: fechaPub ? fechaPub.slice(0, 10) : null,
          enlace_anuncio: enlaces.principal,
          enlace_secundario: enlaceInfo.principal,
          informacion: norm(row["Información"]),
          observaciones: norm(row["Observaciones"]),
          etapa,
        };

        let licitacionId: string;

        if (!existing) {
          // Nueva
          const { data: ins, error: insErr } = await supabase
            .from("licitaciones")
            .insert({ ...licData, bandeja: "R", estado_workflow: "pendiente" })
            .select("id")
            .single();
          if (insErr) throw new Error(insErr.message);
          licitacionId = ins.id;
          nuevas++;
        } else {
          licitacionId = existing.id;
          // Actualizar campos (último valor)
          const patch: Record<string, unknown> = { ...licData };
          // Si llega 'cancelada', marcar descartada
          if (etapa === "cancelada") {
            patch.descartada = true;
            patch.motivo_descarte = "cancelada_gestboes";
            patch.estado_workflow =
              existing.bandeja === "R" ? "descartada_auto" : "descartada";
          }
          const { error: upErr } = await supabase
            .from("licitaciones")
            .update(patch as never)
            .eq("id", licitacionId);
          if (upErr) throw new Error(upErr.message);
          actualizadas++;
        }

        // Anuncio (hijo)
        const { error: anErr } = await supabase.from("anuncios").insert({
          licitacion_id: licitacionId,
          fecha_publicacion: fechaPub ? fechaPub.slice(0, 10) : null,
          etapa,
          estado_raw: estadoRaw,
          importe_euros: importe,
          descripcion: licData.descripcion,
          organismo: licData.organismo,
          enlace_anuncio: enlaces.principal,
          fecha_limite: fechaLimite,
          fecha_orientativa: fechaOrientativa,
          forma_adjudicacion: licData.forma_adjudicacion,
          raw_jsonb: JSON.parse(JSON.stringify(row)),
        });
        if (anErr) throw new Error(anErr.message);
        anuncios++;

        // CPVs
        if (cpvs.length > 0) {
          // Upsert master cpvs
          await supabase.from("cpvs").upsert(
            cpvs.map((c) => ({ codigo: c.codigo, descripcion: c.descripcion })),
            { onConflict: "codigo", ignoreDuplicates: false },
          );
          await supabase
            .from("licitacion_cpvs")
            .upsert(
              cpvs.map((c) => ({ licitacion_id: licitacionId, cpv_codigo: c.codigo })),
              { onConflict: "licitacion_id,cpv_codigo", ignoreDuplicates: true },
            );
        }
      } catch (err) {
        errores.push({ fila: i + 2, error: err instanceof Error ? err.message : String(err) });
      }
    }

    // Auto rules después de la ingesta
    const nowIso = new Date().toISOString();
    await supabase
      .from("licitaciones")
      .update({ estado_workflow: "descartada_auto", descartada: true, motivo_descarte: "auto_fecha_R" })
      .eq("bandeja", "R")
      .eq("estado_workflow", "pendiente")
      .lt("fecha_limite", nowIso);
    await supabase
      .from("licitaciones")
      .update({ estado_workflow: "descartada", descartada: true, motivo_descarte: "auto_fecha_E" })
      .eq("bandeja", "E")
      .eq("estado_workflow", "pendiente")
      .lt("fecha_limite", nowIso);

    // Registrar ingesta
    await supabase.from("ingestas").insert({
      filename: data.filename,
      uploaded_by: userId,
      total_filas: rows.length,
      nuevas_licitaciones: nuevas,
      licitaciones_actualizadas: actualizadas,
      anuncios_anadidos: anuncios,
      errores: errores.length > 0 ? errores : null,
    });

    return { total: rows.length, nuevas, actualizadas, anuncios, errores };
  });

export const listIngestas = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: isDir } = await supabase.rpc("is_direccion", { _user_id: userId });
    if (!isDir) throw new Error("Forbidden: solo dirección puede ver ingestas");
    const { data, error } = await supabase
      .from("ingestas")
      .select("*")
      .order("uploaded_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return data ?? [];
  });
