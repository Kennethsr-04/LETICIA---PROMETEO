import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertDireccion(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("is_direccion", {
    _user_id: context.userId,
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: requiere rol direccion");
}

export const listUsuarios = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertDireccion(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [{ data: profiles, error: pErr }, { data: roles, error: rErr }] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, nombre, codigo_persona, activo, created_at"),
      supabaseAdmin.from("user_roles").select("user_id, role"),
    ]);
    if (pErr) throw new Error(pErr.message);
    if (rErr) throw new Error(rErr.message);

    // Fetch emails via admin auth (paginated)
    const emails: Record<string, string> = {};
    let page = 1;
    while (true) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      for (const u of data.users) emails[u.id] = u.email ?? "";
      if (data.users.length < 200) break;
      page += 1;
      if (page > 25) break;
    }

    const rolesByUser: Record<string, string[]> = {};
    for (const r of roles ?? []) {
      (rolesByUser[r.user_id] ??= []).push(r.role as string);
    }

    return (profiles ?? []).map((p) => ({
      id: p.id,
      nombre: p.nombre,
      email: emails[p.id] ?? "",
      codigo_persona: p.codigo_persona,
      activo: p.activo,
      created_at: p.created_at,
      roles: rolesByUser[p.id] ?? [],
      isDireccion: (rolesByUser[p.id] ?? []).includes("direccion"),
    }));
  });

export const setDireccionRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ userId: z.string().uuid(), enable: z.boolean() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertDireccion(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (data.enable) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert(
          { user_id: data.userId, role: "direccion" },
          { onConflict: "user_id,role", ignoreDuplicates: true },
        );
      if (error) throw new Error(error.message);
    } else {
      if (data.userId === context.userId) {
        throw new Error("No puedes quitarte el rol direccion a ti mismo");
      }
      const { error } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", data.userId)
        .eq("role", "direccion");
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });
