import { Link, useRouterState } from "@tanstack/react-router";
import {
  Inbox,
  ClipboardCheck,
  PenTool,
  Send,
  BarChart3,
  Settings,
  Database,
  Layers,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { getBandejaCounts } from "@/lib/leticia/licitaciones.functions";
import { getMyProfile } from "@/lib/leticia/maestros.functions";
import type { Bandeja } from "@/lib/leticia/types";

const bandejaItems: { code: Bandeja; title: string; url: string; icon: typeof Inbox }[] = [
  { code: "R", title: "Recibidas", url: "/recibidas", icon: Inbox },
  { code: "E", title: "Evaluar", url: "/evaluar", icon: ClipboardCheck },
  { code: "P", title: "Preparar", url: "/preparar", icon: PenTool },
  { code: "L", title: "Licitadas", url: "/licitadas", icon: Send },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const currentPath = useRouterState({ select: (r) => r.location.pathname });

  const { data: counts } = useQuery({
    queryKey: ["bandeja-counts"],
    queryFn: () => getBandejaCounts(),
    refetchInterval: 30_000,
  });

  const { data: me } = useQuery({
    queryKey: ["me"],
    queryFn: () => getMyProfile(),
  });

  const isActive = (path: string) =>
    currentPath === path || currentPath.startsWith(path + "/");

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        <div className="px-4 py-4 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground font-bold">
              L
            </div>
            {!collapsed && (
              <div>
                <div className="font-bold text-sidebar-foreground leading-none">Leticia</div>
                <div className="text-[10px] text-sidebar-foreground/60 mt-0.5">Licitaciones</div>
              </div>
            )}
          </div>
        </div>

        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel>Flujo</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {bandejaItems.map((item) => (
                <SidebarMenuItem key={item.code}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={item.title}>
                    <Link to={item.url}>
                      <item.icon />
                      {!collapsed && (
                        <>
                          <span className="flex-1">
                            {item.title}
                          </span>
                          {counts && counts[item.code] > 0 && (
                            <span className="ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded bg-sidebar-accent">
                              {counts[item.code]}
                            </span>
                          )}
                        </>
                      )}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel>Análisis</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/indicadores")} tooltip="Indicadores">
                  <Link to="/indicadores">
                    <BarChart3 />
                    {!collapsed && <span>Indicadores</span>}
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel>Configuración</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/maestros")} tooltip="Maestros">
                  <Link to="/maestros">
                    <Layers />
                    {!collapsed && <span>Maestros</span>}
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              {me?.isDireccion && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={isActive("/admin")} tooltip="Administración">
                    <Link to="/admin">
                      <Settings />
                      {!collapsed && <span>Administración</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
              {me?.isDireccion && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={isActive("/admin/ingesta")} tooltip="Ingesta">
                    <Link to="/admin/ingesta">
                      <Database />
                      {!collapsed && <span>Ingesta Gestboes</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
              {me?.isDireccion && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={isActive("/admin/usuarios")} tooltip="Usuarios">
                    <Link to="/admin/usuarios">
                      <Settings />
                      {!collapsed && <span>Usuarios</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
