import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, X } from "lucide-react";
import { listPersonas } from "@/lib/leticia/maestros.functions";
import { transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

function usePersonaMutation(licitacionId: string, onSuccess?: () => void) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (personaId: number | null) =>
      transitionLicitacion({ data: { id: licitacionId, action: "asignar", personaId } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      qc.invalidateQueries({ queryKey: ["licitacion", licitacionId] });
      toast.success("Asignación actualizada");
      onSuccess?.();
    },
  });
}

export function AsignarPersonaSubmenu({
  licitacionId,
  current,
  label = "Asignar persona",
  onSuccess,
}: {
  licitacionId: string;
  current: number | null;
  label?: string;
  onSuccess?: () => void;
}) {
  const { data: personas } = useQuery({ queryKey: ["personas"], queryFn: () => listPersonas() });
  const m = usePersonaMutation(licitacionId, onSuccess);
  return (
    <DropdownMenuSub>
      <DropdownMenuSubTrigger>{label}</DropdownMenuSubTrigger>
      <DropdownMenuSubContent className="w-52">
        {personas?.map((p) => (
          <DropdownMenuItem key={p.id} onClick={() => m.mutate(p.id)}>
            <span className="font-mono text-xs opacity-60 w-6">
              {String(p.id).padStart(2, "0")}
            </span>
            <span className="flex-1">{p.nombre}</span>
            {current === p.id && <Check className="w-3.5 h-3.5 text-primary" />}
          </DropdownMenuItem>
        ))}
        {current != null && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => m.mutate(null)}
              className="text-destructive focus:text-destructive"
            >
              <X className="w-3.5 h-3.5" />
              Quitar asignación
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuSubContent>
    </DropdownMenuSub>
  );
}
