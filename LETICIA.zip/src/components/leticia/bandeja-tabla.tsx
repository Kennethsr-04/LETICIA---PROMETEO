import { Link } from "@tanstack/react-router";
import { ExternalLink, MoreHorizontal, ArrowUpDown } from "lucide-react";
import type { Licitacion } from "@/lib/leticia/types";
import { formatEuros, formatFechaCorta, formatHora, shortId } from "@/lib/leticia/format";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { EtapaBadge, EstadoBadge } from "./badges";
import { cn } from "@/lib/utils";

export type ColumnKey =
  | "id"
  | "fecha"
  | "hora"
  | "interes"
  | "persona"
  | "empresa"
  | "organismo"
  | "descripcion"
  | "importe"
  | "evaluada"
  | "cpvs"
  | "enlace"
  | "etapa"
  | "estado";

type ColumnDef = {
  key: ColumnKey;
  label: string;
  sortable?: boolean;
  className?: string;
};

interface Props {
  rows: Licitacion[];
  columns: ColumnKey[];
  basePath: string; // /recibidas, /evaluar, etc.
  actions?: (row: Licitacion) => React.ReactNode;
  orderBy: string;
  orderDir: "asc" | "desc";
  onSort?: (key: string) => void;
}

const ALL_COLUMNS: Record<ColumnKey, ColumnDef> = {
  id: { key: "id", label: "ID", className: "w-20" },
  fecha: { key: "fecha", label: "Fecha", sortable: true, className: "w-24" },
  hora: { key: "hora", label: "Hora", className: "w-16" },
  interes: { key: "interes", label: "Int.", sortable: true, className: "w-12 text-center" },
  persona: { key: "persona", label: "Pers.", className: "w-20" },
  empresa: { key: "empresa", label: "Emp.", className: "w-14" },
  organismo: { key: "organismo", label: "Organismo", sortable: true, className: "w-48" },
  descripcion: { key: "descripcion", label: "Descripción", sortable: true },
  importe: { key: "importe", label: "Importe", sortable: true, className: "w-28 text-right" },
  evaluada: { key: "evaluada", label: "Eval.", className: "w-14 text-center" },
  cpvs: { key: "cpvs", label: "CPVs", className: "w-32" },
  enlace: { key: "enlace", label: "", className: "w-8" },
  etapa: { key: "etapa", label: "Etapa", className: "w-24" },
  estado: { key: "estado", label: "Estado", className: "w-28" },
};

const COL_TO_FIELD: Record<string, string> = {
  fecha: "fecha_limite",
  hora: "fecha_limite",
  importe: "importe_euros",
  organismo: "organismo",
  descripcion: "descripcion",
  interes: "interes",
};

export function BandejaTabla({ rows, columns, basePath, actions, orderBy, orderDir, onSort }: Props) {
  return (
    <div className="border border-border rounded-md overflow-hidden bg-card">
      <div className="overflow-x-auto">
        <table className="w-full text-sm data-table">
          <thead className="bg-muted/40 border-b border-border">
            <tr>
              {columns.map((c) => {
                const col = ALL_COLUMNS[c];
                const field = COL_TO_FIELD[c];
                const active = field === orderBy;
                return (
                  <th
                    key={c}
                    className={cn("px-2.5 py-2 text-left align-middle", col.className)}
                  >
                    {col.sortable && onSort && field ? (
                      <button
                        onClick={() => onSort(field)}
                        className="flex items-center gap-1 hover:text-foreground transition-colors"
                      >
                        {col.label}
                        <ArrowUpDown
                          className={cn(
                            "w-3 h-3",
                            active ? "text-primary" : "opacity-40",
                          )}
                        />
                        {active && (
                          <span className="text-[10px]">{orderDir === "asc" ? "↑" : "↓"}</span>
                        )}
                      </button>
                    ) : (
                      col.label
                    )}
                  </th>
                );
              })}
              {actions && <th className="px-2 w-10"></th>}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length + (actions ? 1 : 0)}
                  className="text-center py-12 text-muted-foreground text-sm"
                >
                  No hay licitaciones que mostrar
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr
                key={r.id}
                className={cn(
                  "border-b border-border hover:bg-muted/30 transition-colors",
                  r.descartada && "opacity-50",
                )}
              >
                {columns.map((c) => (
                  <td key={c} className={cn("px-2.5 py-2 align-top", ALL_COLUMNS[c].className)}>
                    <CellContent col={c} row={r} basePath={basePath} />
                  </td>
                ))}
                {actions && (
                  <td className="px-1 align-top">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">{actions(r)}</DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CellContent({
  col,
  row,
  basePath,
}: {
  col: ColumnKey;
  row: Licitacion;
  basePath: string;
}) {
  switch (col) {
    case "id":
      return (
        <Link
          to={`${basePath}/$id` as never}
          params={{ id: row.id } as never}
          className="font-mono text-xs text-primary hover:underline"
        >
          {shortId(row.id)}
        </Link>
      );
    case "fecha":
      return <span className="font-mono text-xs">{formatFechaCorta(row.fecha_limite)}</span>;
    case "hora":
      return <span className="font-mono text-xs">{formatHora(row.fecha_limite)}</span>;
    case "interes":
      return row.interes ? (
        <span className="inline-flex items-center justify-center w-6 h-6 rounded bg-primary/10 text-primary font-mono font-bold text-xs">
          {row.interes}
        </span>
      ) : (
        <span className="text-muted-foreground">—</span>
      );
    case "persona":
      return row.persona ? (
        <span className="text-xs">
          <span className="font-mono opacity-60">{String(row.persona.id).padStart(2, "0")}</span>{" "}
          {row.persona.nombre}
        </span>
      ) : (
        <span className="text-muted-foreground">—</span>
      );
    case "empresa":
      return row.empresa?.codigo ?? <span className="text-muted-foreground">—</span>;
    case "organismo":
      return <span className="text-xs">{row.organismo || "—"}</span>;
    case "descripcion":
      return <div className="text-xs clamp-3 leading-snug">{row.descripcion || "—"}</div>;
    case "importe":
      return (
        <span className="font-mono text-xs whitespace-nowrap">
          {formatEuros(row.importe_euros)}
        </span>
      );
    case "evaluada":
      return row.evaluada ? (
        <span className="inline-flex w-2 h-2 rounded-full bg-success" />
      ) : (
        <span className="text-muted-foreground">—</span>
      );
    case "cpvs":
      return (
        <div className="text-xs clamp-3 leading-snug font-mono">
          {row.cpvs?.slice(0, 5).map((c) => c.codigo).join(", ") || "—"}
        </div>
      );
    case "enlace":
      return row.enlace_anuncio ? (
        <a
          href={row.enlace_anuncio}
          target="_blank"
          rel="noreferrer"
          className="text-primary hover:text-primary/70"
        >
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      ) : (
        <span className="text-muted-foreground">—</span>
      );
    case "etapa":
      return <EtapaBadge etapa={row.etapa} />;
    case "estado":
      return <EstadoBadge estado={row.estado_workflow} />;
  }
}
