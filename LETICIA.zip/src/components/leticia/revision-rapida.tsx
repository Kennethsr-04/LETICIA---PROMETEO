import { useEffect, useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { formatEuros, formatFechaCorta } from "@/lib/leticia/format";
import type { Licitacion } from "@/lib/leticia/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Props {
  rows: Licitacion[];
  onClose: () => void;
}

export function RevisionRapida({ rows: initialRows, onClose }: Props) {
  const qc = useQueryClient();
  const [rows, setRows] = useState<Licitacion[]>(initialRows);
  const [idx, setIdx] = useState(0);
  const [buffer, setBuffer] = useState<string>("");
  const bufferTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    setRows(initialRows);
  }, [initialRows]);

  const m = useMutation({
    mutationFn: (vars: { id: string; action: "descartar_R" | "asignar"; personaId?: number | null }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  // Update local optimistically
  const updateLocal = (id: string, patch: Partial<Licitacion>) => {
    setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  };

  const advance = () => setIdx((i) => Math.min(i + 1, rows.length - 1));
  const back = () => setIdx((i) => Math.max(i - 1, 0));

  const clearBuffer = () => {
    setBuffer("");
    if (bufferTimer.current) window.clearTimeout(bufferTimer.current);
  };

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        advance();
        clearBuffer();
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        back();
        clearBuffer();
        return;
      }
      const current = rows[idx];
      if (!current) return;

      if (e.key === "n" || e.key === "N") {
        e.preventDefault();
        setBuffer("n");
        updateLocal(current.id, { descartada: true, motivo_descarte: "manual_R" });
        return;
      }
      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        const personaId = parseInt(e.key, 10);
        setBuffer(e.key);
        updateLocal(current.id, { asignado_persona_id: personaId, descartada: false });
        return;
      }
      if (e.key === "Enter") {
        e.preventDefault();
        if (buffer === "n") {
          m.mutate({ id: current.id, action: "descartar_R" });
          clearBuffer();
          advance();
          return;
        }
        if (/^[0-9]$/.test(buffer)) {
          m.mutate({ id: current.id, action: "asignar", personaId: parseInt(buffer, 10) });
          clearBuffer();
          advance();
          return;
        }
        advance();
        return;
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [idx, rows, buffer, onClose, m]);

  if (rows.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-background/95 flex items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">No hay licitaciones pendientes para revisar.</p>
          <Button onClick={onClose}>Cerrar</Button>
        </div>
      </div>
    );
  }

  const prev = idx > 0 ? rows[idx - 1] : null;
  const current = rows[idx];
  const next = idx < rows.length - 1 ? rows[idx + 1] : null;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col">
      <div className="flex items-center justify-between px-4 py-2 border-b border-border">
        <div className="text-sm">
          <span className="font-semibold">Revisión rápida</span>
          <span className="text-muted-foreground ml-3 font-mono">
            {idx + 1} / {rows.length}
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <Shortcut k="n">descartar</Shortcut>
          <Shortcut k="0-8">asignar</Shortcut>
          <Shortcut k="↵">confirmar y avanzar</Shortcut>
          <Shortcut k="↑↓">navegar</Shortcut>
          <Shortcut k="Esc">salir</Shortcut>
          <Button size="sm" variant="ghost" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        <div className="max-w-4xl mx-auto space-y-3">
          {prev && <FichaReducida lic={prev} state="prev" />}
          <FichaReducida lic={current} state="current" buffer={buffer} />
          {next && <FichaReducida lic={next} state="next" />}
        </div>
      </div>
    </div>
  );
}

function Shortcut({ k, children }: { k: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1">
      <kbd className="px-1.5 py-0.5 rounded bg-muted border border-border font-mono text-[10px]">{k}</kbd>
      <span>{children}</span>
    </div>
  );
}

function FichaReducida({
  lic,
  state,
  buffer,
}: {
  lic: Licitacion;
  state: "prev" | "current" | "next";
  buffer?: string;
}) {
  const [showFull, setShowFull] = useState(false);
  const descripcion = lic.descripcion || "";
  const isLong = descripcion.length > 256;
  const preview = isLong && !showFull ? descripcion.slice(0, 256) + "…" : descripcion;

  return (
    <div
      className={cn(
        "rounded-lg border transition-all",
        state === "current" && "bg-card border-primary shadow-lg",
        state === "prev" && "bg-muted/40 border-border text-muted-foreground opacity-70",
        state === "next" && "bg-muted/20 border-border opacity-70",
      )}
    >
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-xs text-muted-foreground font-mono mb-1">
              {formatFechaCorta(lic.fecha_limite)} · {lic.organismo || "Sin organismo"}
            </div>
            <div className="text-sm leading-snug">{preview}</div>
            {isLong && state === "current" && (
              <button
                onClick={() => setShowFull((v) => !v)}
                className="text-xs text-primary hover:underline mt-1"
              >
                {showFull ? "ver menos" : "ver más"}
              </button>
            )}
          </div>
          <div className="text-right shrink-0">
            <div className="font-mono text-base font-semibold">{formatEuros(lic.importe_euros)}</div>
            {lic.enlace_anuncio && (
              <a
                href={lic.enlace_anuncio}
                target="_blank"
                rel="noreferrer"
                className="text-primary text-xs inline-flex items-center gap-1 mt-1 hover:underline"
              >
                <ExternalLink className="w-3 h-3" /> Anuncio
              </a>
            )}
          </div>
        </div>

        {lic.cpvs && lic.cpvs.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {lic.cpvs.map((c) => (
              <span
                key={c.codigo}
                className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground"
                title={c.descripcion || ""}
              >
                {c.codigo}
                {c.descripcion && <span className="ml-1 opacity-70">{c.descripcion.slice(0, 30)}</span>}
              </span>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3 text-xs pt-2 border-t border-border/60">
          <div className="flex items-center gap-1.5">
            <span className="text-muted-foreground">Descarte:</span>
            <span
              className={cn(
                "font-mono font-semibold px-2 py-0.5 rounded min-w-8 text-center",
                lic.descartada ? "bg-destructive/15 text-destructive" : "bg-muted/40",
              )}
            >
              {lic.descartada ? "NO" : "—"}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-muted-foreground">Asignación:</span>
            <span
              className={cn(
                "font-mono font-semibold px-2 py-0.5 rounded min-w-8 text-center",
                lic.asignado_persona_id != null ? "bg-primary/15 text-primary" : "bg-muted/40",
              )}
            >
              {lic.asignado_persona_id != null
                ? String(lic.asignado_persona_id).padStart(2, "0")
                : "—"}
            </span>
          </div>
          {state === "current" && buffer && (
            <div className="ml-auto flex items-center gap-1 text-muted-foreground">
              buffer:
              <kbd className="px-1.5 py-0.5 rounded bg-primary text-primary-foreground font-mono">
                {buffer}
              </kbd>
              <span className="text-[10px]">(↵ para confirmar)</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
