import { useQuery, useQueryClient } from "@tanstack/react-query";
import { LogOut, Shield, User as UserIcon } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { getMyProfile, listPersonas, updateMyCodigoPersona } from "@/lib/leticia/maestros.functions";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export function HeaderUser() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const { data: personas } = useQuery({ queryKey: ["personas"], queryFn: () => listPersonas() });

  async function handleSignOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const personaActual = me?.profile?.codigo_persona;
  const personaNombre = personas?.find((p) => p.id === personaActual)?.nombre;

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2 h-8">
            <UserIcon className="w-4 h-4" />
            <span className="text-sm font-medium">{me?.profile?.nombre || "Usuario"}</span>
            {personaNombre && (
              <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-muted">
                {String(personaActual).padStart(2, "0")} · {personaNombre}
              </span>
            )}
            {me?.isDireccion && (
              <span className="text-xs px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium flex items-center gap-1">
                <Shield className="w-3 h-3" /> Dirección
              </span>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>{me?.profile?.nombre}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setOpen(true)}>
            <UserIcon className="w-4 h-4" />
            Mi persona Gestboes
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Asigna tu código de persona</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Label>Persona</Label>
            <Select
              value={personaActual != null ? String(personaActual) : ""}
              onValueChange={async (v) => {
                await updateMyCodigoPersona({ data: { codigo_persona: v === "" ? null : Number(v) } });
                toast.success("Actualizado");
                qc.invalidateQueries({ queryKey: ["me"] });
                setOpen(false);
              }}
            >
              <SelectTrigger><SelectValue placeholder="Selecciona…" /></SelectTrigger>
              <SelectContent>
                {personas?.map((p) => (
                  <SelectItem key={p.id} value={String(p.id)}>
                    {String(p.id).padStart(2, "0")} · {p.nombre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Este código se usa para filtrar tus licitaciones asignadas.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
