import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ChevronLeft, ExternalLink, Trash2, Check, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  getLicitacion,
  listLicitaciones,
  transitionLicitacion,
  updateLicitacion,
} from "@/lib/leticia/licitaciones.functions";
import { listEmpresas, listPersonas, listTags, setLicitacionTags, getMyProfile } from "@/lib/leticia/maestros.functions";
import { EtapaBadge, EstadoBadge } from "./badges";
import { formatEuros, formatFechaCorta, formatFechaHora } from "@/lib/leticia/format";
import type { Bandeja } from "@/lib/leticia/types";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Props {
  id: string;
  bandeja: Bandeja;
  basePath: string;
}

export function LicitacionFicha({ id, bandeja, basePath }: Props) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [editing, setEditing] = useState<Record<string, unknown>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["licitacion", id],
    queryFn: () => getLicitacion({ data: { id } }),
  });
  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const { data: personas } = useQuery({ queryKey: ["personas"], queryFn: () => listPersonas() });
  const { data: empresas } = useQuery({ queryKey: ["empresas"], queryFn: () => listEmpresas() });
  const { data: tags } = useQuery({ queryKey: ["tags"], queryFn: () => listTags() });

  // Siblings for nav
  const { data: siblings } = useQuery({
    queryKey: ["licitaciones-nav", bandeja],
    queryFn: () =>
      listLicitaciones({
        data: { bandeja, orderBy: "fecha_limite", orderDir: "asc" },
      }),
  });

  const update = useMutation({
    mutationFn: (patch: Record<string, unknown>) => updateLicitacion({ data: { id, patch } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitacion", id] });
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      toast.success("Guardado");
      setEditing({});
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  const transition = useMutation({
    mutationFn: (vars: { action: "descartar_R" | "descartar_E" | "descartar_P" | "pasar_a_preparar" | "pasar_a_licitada" | "marcar_evaluada" | "marcar_ganada" | "marcar_perdida"; personaId?: number | null }) =>
      transitionLicitacion({ data: { id, ...vars } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitacion", id] });
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
  });

  const setTagsMut = useMutation({
    mutationFn: (tagIds: string[]) => setLicitacionTags({ data: { licitacionId: id, tagIds } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["licitacion", id] }),
  });

  // Nav siblings
  const sibList = (siblings ?? []) as unknown as { id: string }[];
  const sibIdx = sibList.findIndex((s) => s.id === id);
  const prevId = sibIdx > 0 ? sibList[sibIdx - 1].id : null;
  const nextId = sibIdx >= 0 && sibIdx < sibList.length - 1 ? sibList[sibIdx + 1].id : null;

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === "ArrowLeft" && prevId) {
        navigate({ to: `${basePath}/$id` as never, params: { id: prevId } as never });
      } else if (e.key === "ArrowRight" && nextId) {
        navigate({ to: `${basePath}/$id` as never, params: { id: nextId } as never });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [prevId, nextId, navigate, basePath]);

  if (isLoading || !data) return <div className="p-6 text-sm text-muted-foreground">Cargando…</div>;
  const lic = data.licitacion;
  const anuncios = data.anuncios;
  const canEditPersona = me?.isDireccion || me?.profile?.codigo_persona === 0;

  const setField = (k: string, v: unknown) => setEditing((p) => ({ ...p, [k]: v }));
  const getVal = (k: string, fallback: unknown) => (k in editing ? editing[k] : fallback);

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Top bar */}
      <div className="flex items-center justify-between gap-2">
        <Button
          size="sm"
          variant="ghost"
          onClick={() => navigate({ to: basePath as never })}
          className="gap-1"
        >
          <ChevronLeft className="w-4 h-4" />
          Volver al listado
        </Button>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            disabled={!prevId}
            onClick={() => prevId && navigate({ to: `${basePath}/$id` as never, params: { id: prevId } as never })}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="text-xs text-muted-foreground font-mono">
            {sibIdx >= 0 ? `${sibIdx + 1} / ${sibList.length}` : ""}
          </div>
          <Button
            size="sm"
            variant="outline"
            disabled={!nextId}
            onClick={() => nextId && navigate({ to: `${basePath}/$id` as never, params: { id: nextId } as never })}
          >
            <ArrowRight className="w-4 h-4" />
          </Button>
          {bandeja === "E" && (
            <Button size="sm" onClick={() => transition.mutate({ action: "pasar_a_preparar" })}>
              Preparar →
            </Button>
          )}
          {bandeja === "P" && (
            <Button size="sm" onClick={() => transition.mutate({ action: "pasar_a_licitada" })}>
              Licitada →
            </Button>
          )}
          {bandeja === "L" && (
            <>
              <Button size="sm" variant="outline" onClick={() => transition.mutate({ action: "marcar_ganada" })}>
                Ganada
              </Button>
              <Button size="sm" variant="outline" onClick={() => transition.mutate({ action: "marcar_perdida" })}>
                Perdida
              </Button>
            </>
          )}
          {bandeja !== "L" && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() =>
                transition.mutate({
                  action:
                    bandeja === "R" ? "descartar_R" : bandeja === "E" ? "descartar_E" : "descartar_P",
                })
              }
              className="text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
          {Object.keys(editing).length > 0 && (
            <Button size="sm" onClick={() => update.mutate(editing)} className="gap-1">
              <Save className="w-4 h-4" /> Guardar
            </Button>
          )}
        </div>
      </div>

      {/* CABECERA */}
      <div className="bg-card border border-border rounded-md p-3">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <Field label="ID">
            <span className="font-mono text-xs">{lic.id.slice(0, 8)}</span>
          </Field>
          <Field label="Fecha / Hora límite">{formatFechaHora(lic.fecha_limite)}</Field>
          <Field label="Etapa"><EtapaBadge etapa={lic.etapa} /></Field>
          <Field label="Estado"><EstadoBadge estado={lic.estado_workflow} /></Field>
          <Field label="Descarte">
            <span
              className={cn(
                "font-mono text-xs px-1.5 rounded",
                lic.descartada ? "bg-destructive/15 text-destructive" : "bg-muted",
              )}
            >
              {lic.descartada ? "D" : "—"}
            </span>
          </Field>
          <Field label="Interés">
            <Select
              value={String(getVal("interes", lic.interes) ?? "")}
              onValueChange={(v) => setField("interes", v ? Number(v) : null)}
            >
              <SelectTrigger className="h-7 w-16 text-xs">
                <SelectValue placeholder="—" />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                  <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Empresa">
            <Select
              value={String(getVal("empresa_id", lic.empresa_id) ?? "")}
              onValueChange={(v) => setField("empresa_id", v || null)}
            >
              <SelectTrigger className="h-7 w-20 text-xs">
                <SelectValue placeholder="—" />
              </SelectTrigger>
              <SelectContent>
                {empresas?.map((e) => (
                  <SelectItem key={e.id} value={e.id}>{e.codigo}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          {bandeja !== "R" && canEditPersona && (
            <Field label="Persona">
              <Select
                value={String(getVal("asignado_persona_id", lic.asignado_persona_id) ?? "")}
                onValueChange={(v) => setField("asignado_persona_id", v ? Number(v) : null)}
              >
                <SelectTrigger className="h-7 w-32 text-xs">
                  <SelectValue placeholder="—" />
                </SelectTrigger>
                <SelectContent>
                  {personas?.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {String(p.id).padStart(2, "0")} · {p.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          )}
          {bandeja !== "R" && (
            <Field label="Tags" className="flex-1 min-w-[200px]">
              <TagsEditor
                value={lic.tags?.map((t) => t.id) ?? []}
                allTags={tags ?? []}
                onChange={(ids) => setTagsMut.mutate(ids)}
              />
            </Field>
          )}
          <div className="ml-auto flex items-center gap-2">
            {lic.enlace_anuncio && (
              <a href={lic.enlace_anuncio} target="_blank" rel="noreferrer" className="text-primary">
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
            {lic.enlace_secundario && (
              <a href={lic.enlace_secundario} target="_blank" rel="noreferrer" className="text-muted-foreground">
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
          </div>
        </div>
      </div>

      {/* DATOS PRINCIPALES */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-md p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <KV label="Código Gestboes" value={lic.codigo_gestboes} mono />
            <KV label="Expediente" value={lic.expediente} mono />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Descripción</Label>
            <Textarea
              value={String(getVal("descripcion", lic.descripcion ?? "") ?? "")}
              onChange={(e) => setField("descripcion", e.target.value)}
              className="text-sm mt-1 min-h-[80px]"
            />
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <KV label="Contrato" value={lic.contrato} />
            <KV label="Importe (€)" value={formatEuros(lic.importe_euros)} mono />
          </div>
          <KV label="Organismo" value={lic.organismo} />
          <div className="grid grid-cols-3 gap-3">
            <KV label="Provincia" value={lic.provincia} />
            <KV label="Autonomía" value={lic.autonomia} />
            <KV label="Población" value={lic.poblacion} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <KV label="Plazo (meses)" value={lic.plazo_meses != null ? lic.plazo_meses.toFixed(1) : "—"} mono />
            <KV label="Prórroga (años)" value={lic.prorroga_anios != null ? lic.prorroga_anios.toFixed(1) : "—"} mono />
            <KV label="Forma adjudicación" value={lic.forma_adjudicacion} />
          </div>
          {bandeja !== "R" && (
            <div>
              <Label className="text-xs text-muted-foreground">Comentarios evaluación</Label>
              <Textarea
                value={String(getVal("comentarios_evaluacion", lic.comentarios_evaluacion ?? "") ?? "")}
                onChange={(e) => setField("comentarios_evaluacion", e.target.value)}
                className="text-sm mt-1 min-h-[80px]"
              />
            </div>
          )}
          {bandeja === "E" && !lic.evaluada && (
            <Button size="sm" variant="outline" onClick={() => transition.mutate({ action: "marcar_evaluada" })} className="gap-1">
              <Check className="w-4 h-4" /> Marcar evaluada
            </Button>
          )}
        </div>

        <div className="bg-card border border-border rounded-md p-4">
          <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-3">CPVs</h3>
          {lic.cpvs && lic.cpvs.length > 0 ? (
            <ul className="space-y-1.5">
              {lic.cpvs.map((c) => (
                <li key={c.codigo} className="text-sm">
                  <div className="font-mono text-xs text-primary">{c.codigo}</div>
                  {c.descripcion && <div className="text-xs text-muted-foreground">{c.descripcion}</div>}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-muted-foreground">Sin CPVs</p>
          )}
        </div>
      </div>

      {/* ANUNCIOS */}
      <div className="bg-card border border-border rounded-md p-4">
        <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-3">
          Anuncios publicados ({anuncios.length})
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm data-table">
            <thead>
              <tr className="border-b">
                <th className="text-left px-2 py-1.5">Fecha</th>
                <th className="text-left px-2 py-1.5">Etapa</th>
                <th className="text-left px-2 py-1.5">Estado raw</th>
                <th className="text-left px-2 py-1.5">Descripción</th>
                <th className="text-left px-2 py-1.5">Organismo</th>
                <th className="text-right px-2 py-1.5">Importe</th>
                <th className="px-2 py-1.5"></th>
              </tr>
            </thead>
            <tbody>
              {anuncios.map((a) => (
                <tr key={a.id} className="border-b border-border/60">
                  <td className="px-2 py-1.5 font-mono text-xs">{formatFechaCorta(a.fecha_publicacion)}</td>
                  <td className="px-2 py-1.5">{a.etapa && <EtapaBadge etapa={a.etapa} />}</td>
                  <td className="px-2 py-1.5 text-xs text-muted-foreground">{a.estado_raw}</td>
                  <td className="px-2 py-1.5 text-xs clamp-2">{a.descripcion}</td>
                  <td className="px-2 py-1.5 text-xs">{a.organismo}</td>
                  <td className="px-2 py-1.5 font-mono text-xs text-right">{formatEuros(a.importe_euros)}</td>
                  <td className="px-2 py-1.5">
                    {a.enlace_anuncio && (
                      <a href={a.enlace_anuncio} target="_blank" rel="noreferrer" className="text-primary">
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </td>
                </tr>
              ))}
              {anuncios.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center text-muted-foreground py-4 text-xs">
                    Sin anuncios registrados
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span className="text-xs text-muted-foreground uppercase font-medium">{label}:</span>
      {children}
    </div>
  );
}

function KV({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <div className={cn("text-sm mt-0.5", mono && "font-mono")}>{value || "—"}</div>
    </div>
  );
}

function TagsEditor({
  value,
  allTags,
  onChange,
}: {
  value: string[];
  allTags: { id: string; nombre: string }[];
  onChange: (ids: string[]) => void;
}) {
  const toggle = (id: string) => {
    if (value.includes(id)) onChange(value.filter((x) => x !== id));
    else onChange([...value, id]);
  };
  return (
    <div className="flex flex-wrap gap-1">
      {allTags.length === 0 && <span className="text-xs text-muted-foreground">Sin tags</span>}
      {allTags.map((t) => (
        <button
          key={t.id}
          onClick={() => toggle(t.id)}
          className={cn(
            "text-xs px-2 py-0.5 rounded border transition-colors",
            value.includes(t.id)
              ? "bg-primary text-primary-foreground border-primary"
              : "bg-muted/40 border-border hover:bg-muted",
          )}
        >
          {t.nombre}
        </button>
      ))}
    </div>
  );
}
