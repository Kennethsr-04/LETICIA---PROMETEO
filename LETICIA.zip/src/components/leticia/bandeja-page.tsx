import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, Plus, PlayCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Toggle } from "@/components/ui/toggle";
import { BandejaTabla, type ColumnKey } from "./bandeja-tabla";
import { listLicitaciones, transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import type { Bandeja, Licitacion } from "@/lib/leticia/types";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useNavigate } from "@tanstack/react-router";

interface FilterTabsProps {
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}

function FilterTabs({ value, options, onChange }: FilterTabsProps) {
  return (
    <div className="flex items-center gap-1 text-xs">
      {options.map((o) => (
        <Toggle
          key={o.value}
          pressed={value === o.value}
          onPressedChange={() => onChange(o.value)}
          size="sm"
          variant="outline"
          className={cn("h-7 px-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground")}
        >
          {o.label}
        </Toggle>
      ))}
    </div>
  );
}

interface Props {
  bandeja: Bandeja;
  titulo: string;
  columns: ColumnKey[];
  basePath: string;
  defaultFilters?: {
    estadosWorkflow?: string[];
    etapas?: string[];
  };
  filtroEstadoOptions?: { value: string; label: string; estados: string[] }[];
  filtroEtapaOptions?: { value: string; label: string; etapas: string[] }[];
  extraActions?: React.ReactNode;
  onReview?: () => void;
  rowActions?: (row: Licitacion) => React.ReactNode;
}

export function BandejaPage({
  bandeja,
  titulo,
  columns,
  basePath,
  defaultFilters,
  filtroEstadoOptions,
  filtroEtapaOptions,
  extraActions,
  onReview,
  rowActions,
}: Props) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState(filtroEstadoOptions?.[0]?.value ?? "");
  const [etapaFiltro, setEtapaFiltro] = useState(filtroEtapaOptions?.[0]?.value ?? "");
  const [fechaDesde, setFechaDesde] = useState<Date | undefined>();
  const [fechaHasta, setFechaHasta] = useState<Date | undefined>();
  const [orderBy, setOrderBy] = useState("fecha_limite");
  const [orderDir, setOrderDir] = useState<"asc" | "desc">("asc");

  const estadosWorkflow =
    filtroEstadoOptions?.find((o) => o.value === estadoFiltro)?.estados ?? defaultFilters?.estadosWorkflow ?? [];
  const etapas = filtroEtapaOptions?.find((o) => o.value === etapaFiltro)?.etapas ?? defaultFilters?.etapas ?? [];

  const { data: rows, isLoading } = useQuery({
    queryKey: ["licitaciones", bandeja, search, estadoFiltro, etapaFiltro, fechaDesde, fechaHasta, orderBy, orderDir],
    queryFn: () =>
      listLicitaciones({
        data: {
          bandeja,
          search,
          estadosWorkflow: estadosWorkflow.length ? estadosWorkflow : undefined,
          etapas: etapas.length ? etapas : undefined,
          fechaDesde: fechaDesde?.toISOString() ?? null,
          fechaHasta: fechaHasta?.toISOString() ?? null,
          orderBy,
          orderDir,
        },
      }),
  });

  const transition = useMutation({
    mutationFn: (vars: { id: string; action: "descartar_R" | "descartar_E" | "descartar_P" | "marcar_evaluada" | "desmarcar_evaluada" | "pasar_a_preparar" | "pasar_a_licitada" | "marcar_ganada" | "marcar_perdida" | "restaurar" | "asignar"; personaId?: number | null }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  const handleSort = (field: string) => {
    if (orderBy === field) setOrderDir(orderDir === "asc" ? "desc" : "asc");
    else {
      setOrderBy(field);
      setOrderDir("asc");
    }
  };

  return (
    <div className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">{titulo}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {rows?.length ?? 0} licitaciones
          </p>
        </div>
        <div className="flex items-center gap-2">
          {extraActions}
          {onReview && (
            <Button size="sm" onClick={onReview} className="gap-1.5">
              <PlayCircle className="w-4 h-4" />
              Revisión rápida
            </Button>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 p-2 bg-card border border-border rounded-md">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 pl-7 text-sm"
          />
        </div>

        {filtroEstadoOptions && (
          <FilterTabs value={estadoFiltro} options={filtroEstadoOptions} onChange={setEstadoFiltro} />
        )}
        {filtroEtapaOptions && (
          <FilterTabs value={etapaFiltro} options={filtroEtapaOptions} onChange={setEtapaFiltro} />
        )}

        <DateFilter label="Desde" date={fechaDesde} onChange={setFechaDesde} />
        <DateFilter label="Hasta" date={fechaHasta} onChange={setFechaHasta} />

        {(fechaDesde || fechaHasta) && (
          <Button
            size="sm"
            variant="ghost"
            className="h-7"
            onClick={() => {
              setFechaDesde(undefined);
              setFechaHasta(undefined);
            }}
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-sm text-muted-foreground">Cargando…</div>
      ) : (
        <BandejaTabla
          rows={(rows ?? []) as unknown as Licitacion[]}
          columns={columns}
          basePath={basePath}
          orderBy={orderBy}
          orderDir={orderDir}
          onSort={handleSort}
          actions={rowActions ?? ((row) => (
            <>
              <DropdownMenuItem onClick={() => navigate({ to: `${basePath}/$id` as never, params: { id: row.id } as never })}>
                Ver ficha
              </DropdownMenuItem>
            </>
          ))}
        />
      )}
    </div>
  );
}

function DateFilter({ label, date, onChange }: { label: string; date?: Date; onChange: (d?: Date) => void }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="sm" variant="outline" className="h-7 gap-1 text-xs font-normal">
          <Plus className="w-3 h-3" />
          {label}
          {date && <span className="font-mono">{format(date, "dd/MM/yy", { locale: es })}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar mode="single" selected={date} onSelect={onChange} className="p-3 pointer-events-auto" />
      </PopoverContent>
    </Popover>
  );
}
