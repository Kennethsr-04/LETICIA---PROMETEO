import { cn } from "@/lib/utils";
import type { Etapa, EstadoWorkflow } from "@/lib/leticia/types";

const ETAPA_STYLES: Record<Etapa, string> = {
  previo: "bg-info/10 text-info border-info/30",
  licitacion: "bg-primary/10 text-primary border-primary/30",
  evaluacion: "bg-warning/15 text-warning-foreground border-warning/30",
  cancelada: "bg-destructive/10 text-destructive border-destructive/30",
};

const ETAPA_LABEL: Record<Etapa, string> = {
  previo: "Previo",
  licitacion: "Licitación",
  evaluacion: "Evaluación",
  cancelada: "Cancelada",
};

export function EtapaBadge({ etapa }: { etapa: Etapa }) {
  return (
    <span className={cn("inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium uppercase border", ETAPA_STYLES[etapa])}>
      {ETAPA_LABEL[etapa]}
    </span>
  );
}

const ESTADO_STYLES: Record<EstadoWorkflow, string> = {
  pendiente: "bg-muted text-muted-foreground",
  descartada_manual: "bg-destructive/10 text-destructive",
  descartada_auto: "bg-destructive/10 text-destructive",
  evaluada: "bg-success/15 text-success",
  descartada: "bg-destructive/10 text-destructive",
  preparar: "bg-info/15 text-info",
  presentada: "bg-primary/15 text-primary",
  ganada: "bg-success/20 text-success",
  perdida: "bg-destructive/15 text-destructive",
};

const ESTADO_LABEL: Record<EstadoWorkflow, string> = {
  pendiente: "Pendiente",
  descartada_manual: "Descartada",
  descartada_auto: "Desc. auto",
  evaluada: "Evaluada",
  descartada: "Descartada",
  preparar: "Preparar",
  presentada: "Presentada",
  ganada: "Ganada",
  perdida: "Perdida",
};

export function EstadoBadge({ estado }: { estado: EstadoWorkflow }) {
  return (
    <span className={cn("inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium uppercase", ESTADO_STYLES[estado])}>
      {ESTADO_LABEL[estado]}
    </span>
  );
}
