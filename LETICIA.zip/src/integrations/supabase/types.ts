export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      anuncios: {
        Row: {
          created_at: string
          descripcion: string | null
          enlace_anuncio: string | null
          estado_raw: string | null
          etapa: Database["public"]["Enums"]["etapa_licitacion"] | null
          fecha_limite: string | null
          fecha_orientativa: string | null
          fecha_publicacion: string | null
          forma_adjudicacion: string | null
          id: string
          importe_euros: number | null
          licitacion_id: string
          organismo: string | null
          raw_jsonb: Json | null
        }
        Insert: {
          created_at?: string
          descripcion?: string | null
          enlace_anuncio?: string | null
          estado_raw?: string | null
          etapa?: Database["public"]["Enums"]["etapa_licitacion"] | null
          fecha_limite?: string | null
          fecha_orientativa?: string | null
          fecha_publicacion?: string | null
          forma_adjudicacion?: string | null
          id?: string
          importe_euros?: number | null
          licitacion_id: string
          organismo?: string | null
          raw_jsonb?: Json | null
        }
        Update: {
          created_at?: string
          descripcion?: string | null
          enlace_anuncio?: string | null
          estado_raw?: string | null
          etapa?: Database["public"]["Enums"]["etapa_licitacion"] | null
          fecha_limite?: string | null
          fecha_orientativa?: string | null
          fecha_publicacion?: string | null
          forma_adjudicacion?: string | null
          id?: string
          importe_euros?: number | null
          licitacion_id?: string
          organismo?: string | null
          raw_jsonb?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "anuncios_licitacion_id_fkey"
            columns: ["licitacion_id"]
            isOneToOne: false
            referencedRelation: "licitaciones"
            referencedColumns: ["id"]
          },
        ]
      }
      cpvs: {
        Row: {
          codigo: string
          descripcion: string | null
        }
        Insert: {
          codigo: string
          descripcion?: string | null
        }
        Update: {
          codigo?: string
          descripcion?: string | null
        }
        Relationships: []
      }
      empresas: {
        Row: {
          codigo: string
          id: string
          nombre: string
        }
        Insert: {
          codigo: string
          id?: string
          nombre: string
        }
        Update: {
          codigo?: string
          id?: string
          nombre?: string
        }
        Relationships: []
      }
      ingestas: {
        Row: {
          anuncios_anadidos: number
          errores: Json | null
          filename: string
          id: string
          licitaciones_actualizadas: number
          nuevas_licitaciones: number
          total_filas: number
          uploaded_at: string
          uploaded_by: string | null
        }
        Insert: {
          anuncios_anadidos?: number
          errores?: Json | null
          filename: string
          id?: string
          licitaciones_actualizadas?: number
          nuevas_licitaciones?: number
          total_filas?: number
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Update: {
          anuncios_anadidos?: number
          errores?: Json | null
          filename?: string
          id?: string
          licitaciones_actualizadas?: number
          nuevas_licitaciones?: number
          total_filas?: number
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      licitacion_cpvs: {
        Row: {
          cpv_codigo: string
          licitacion_id: string
        }
        Insert: {
          cpv_codigo: string
          licitacion_id: string
        }
        Update: {
          cpv_codigo?: string
          licitacion_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "licitacion_cpvs_cpv_codigo_fkey"
            columns: ["cpv_codigo"]
            isOneToOne: false
            referencedRelation: "cpvs"
            referencedColumns: ["codigo"]
          },
          {
            foreignKeyName: "licitacion_cpvs_licitacion_id_fkey"
            columns: ["licitacion_id"]
            isOneToOne: false
            referencedRelation: "licitaciones"
            referencedColumns: ["id"]
          },
        ]
      }
      licitacion_tags: {
        Row: {
          licitacion_id: string
          tag_id: string
        }
        Insert: {
          licitacion_id: string
          tag_id: string
        }
        Update: {
          licitacion_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "licitacion_tags_licitacion_id_fkey"
            columns: ["licitacion_id"]
            isOneToOne: false
            referencedRelation: "licitaciones"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "licitacion_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "tags"
            referencedColumns: ["id"]
          },
        ]
      }
      licitaciones: {
        Row: {
          administracion: string | null
          asignado_persona_id: number | null
          autonomia: string | null
          bandeja: Database["public"]["Enums"]["bandeja"]
          codigo_gestboes: string | null
          comentarios_evaluacion: string | null
          contrato: string | null
          created_at: string
          descartada: boolean
          descripcion: string | null
          empresa_id: string | null
          enlace_anuncio: string | null
          enlace_secundario: string | null
          estado_workflow: Database["public"]["Enums"]["estado_workflow"]
          etapa: Database["public"]["Enums"]["etapa_licitacion"]
          evaluada: boolean
          expediente: string | null
          fecha_limite: string | null
          fecha_orientativa: string | null
          fecha_publicacion: string | null
          forma_adjudicacion: string | null
          id: string
          importe_euros: number | null
          informacion: string | null
          interes: number | null
          motivo_descarte: string | null
          observaciones: string | null
          organismo: string | null
          plazo_meses: number | null
          poblacion: string | null
          prorroga_anios: number | null
          provincia: string | null
          updated_at: string
        }
        Insert: {
          administracion?: string | null
          asignado_persona_id?: number | null
          autonomia?: string | null
          bandeja?: Database["public"]["Enums"]["bandeja"]
          codigo_gestboes?: string | null
          comentarios_evaluacion?: string | null
          contrato?: string | null
          created_at?: string
          descartada?: boolean
          descripcion?: string | null
          empresa_id?: string | null
          enlace_anuncio?: string | null
          enlace_secundario?: string | null
          estado_workflow?: Database["public"]["Enums"]["estado_workflow"]
          etapa?: Database["public"]["Enums"]["etapa_licitacion"]
          evaluada?: boolean
          expediente?: string | null
          fecha_limite?: string | null
          fecha_orientativa?: string | null
          fecha_publicacion?: string | null
          forma_adjudicacion?: string | null
          id?: string
          importe_euros?: number | null
          informacion?: string | null
          interes?: number | null
          motivo_descarte?: string | null
          observaciones?: string | null
          organismo?: string | null
          plazo_meses?: number | null
          poblacion?: string | null
          prorroga_anios?: number | null
          provincia?: string | null
          updated_at?: string
        }
        Update: {
          administracion?: string | null
          asignado_persona_id?: number | null
          autonomia?: string | null
          bandeja?: Database["public"]["Enums"]["bandeja"]
          codigo_gestboes?: string | null
          comentarios_evaluacion?: string | null
          contrato?: string | null
          created_at?: string
          descartada?: boolean
          descripcion?: string | null
          empresa_id?: string | null
          enlace_anuncio?: string | null
          enlace_secundario?: string | null
          estado_workflow?: Database["public"]["Enums"]["estado_workflow"]
          etapa?: Database["public"]["Enums"]["etapa_licitacion"]
          evaluada?: boolean
          expediente?: string | null
          fecha_limite?: string | null
          fecha_orientativa?: string | null
          fecha_publicacion?: string | null
          forma_adjudicacion?: string | null
          id?: string
          importe_euros?: number | null
          informacion?: string | null
          interes?: number | null
          motivo_descarte?: string | null
          observaciones?: string | null
          organismo?: string | null
          plazo_meses?: number | null
          poblacion?: string | null
          prorroga_anios?: number | null
          provincia?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "licitaciones_asignado_persona_id_fkey"
            columns: ["asignado_persona_id"]
            isOneToOne: false
            referencedRelation: "personas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "licitaciones_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      personas: {
        Row: {
          activo: boolean
          id: number
          nombre: string
        }
        Insert: {
          activo?: boolean
          id: number
          nombre: string
        }
        Update: {
          activo?: boolean
          id?: number
          nombre?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          activo: boolean
          codigo_persona: number | null
          created_at: string
          id: string
          nombre: string
          updated_at: string
        }
        Insert: {
          activo?: boolean
          codigo_persona?: number | null
          created_at?: string
          id: string
          nombre: string
          updated_at?: string
        }
        Update: {
          activo?: boolean
          codigo_persona?: number | null
          created_at?: string
          id?: string
          nombre?: string
          updated_at?: string
        }
        Relationships: []
      }
      tags: {
        Row: {
          id: string
          nombre: string
        }
        Insert: {
          id?: string
          nombre: string
        }
        Update: {
          id?: string
          nombre?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_codigo_persona: { Args: never; Returns: number }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_direccion: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "direccion" | "comercial"
      bandeja: "R" | "E" | "P" | "L"
      estado_workflow:
        | "pendiente"
        | "descartada_manual"
        | "descartada_auto"
        | "evaluada"
        | "descartada"
        | "preparar"
        | "presentada"
        | "ganada"
        | "perdida"
      etapa_licitacion: "previo" | "licitacion" | "evaluacion" | "cancelada"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["direccion", "comercial"],
      bandeja: ["R", "E", "P", "L"],
      estado_workflow: [
        "pendiente",
        "descartada_manual",
        "descartada_auto",
        "evaluada",
        "descartada",
        "preparar",
        "presentada",
        "ganada",
        "perdida",
      ],
      etapa_licitacion: ["previo", "licitacion", "evaluacion", "cancelada"],
    },
  },
} as const
