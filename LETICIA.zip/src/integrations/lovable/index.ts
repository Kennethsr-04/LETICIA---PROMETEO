// Stub - not using lovable auth broker (email/password only)
export const lovable = {};
