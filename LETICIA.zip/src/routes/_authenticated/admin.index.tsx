import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { getMyProfile } from "@/lib/leticia/maestros.functions";
import { Database, Settings } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
    const me = await getMyProfile();
    if (!me.isDireccion) throw redirect({ to: "/recibidas" });
  },
  component: AdminPage,
});

function AdminPage() {
  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      <h1 className="text-xl font-bold tracking-tight">Administración</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Link to="/admin/ingesta" className="block p-4 border border-border rounded-md bg-card hover:bg-accent transition-colors">
          <Database className="w-6 h-6 text-primary mb-2" />
          <div className="font-semibold">Ingesta Gestboes</div>
          <div className="text-xs text-muted-foreground mt-1">Sube ficheros Excel/XML diarios para crear o actualizar licitaciones.</div>
        </Link>
        <Link to="/admin/usuarios" className="block p-4 border border-border rounded-md bg-card hover:bg-accent transition-colors">
          <Settings className="w-6 h-6 text-primary mb-2" />
          <div className="font-semibold">Usuarios y roles</div>
          <div className="text-xs text-muted-foreground mt-1">Activa o desactiva el rol Dirección para cada usuario.</div>
        </Link>
      </div>
    </div>
  );
}
