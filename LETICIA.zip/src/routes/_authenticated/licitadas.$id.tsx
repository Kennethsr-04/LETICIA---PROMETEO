import { createFileRoute } from "@tanstack/react-router";
import { LicitacionFicha } from "@/components/leticia/licitacion-ficha";

export const Route = createFileRoute("/_authenticated/licitadas/$id")({
  component: () => {
    const { id } = Route.useParams();
    return <LicitacionFicha id={id} bandeja="L" basePath="/licitadas" />;
  },
});
