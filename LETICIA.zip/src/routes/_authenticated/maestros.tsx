import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2, Plus } from "lucide-react";
import {
  createEmpresa,
  createTag,
  deleteTag,
  getMyProfile,
  listEmpresas,
  listPersonas,
  listTags,
  upsertPersona,
} from "@/lib/leticia/maestros.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/maestros")({
  component: MaestrosPage,
});

function MaestrosPage() {
  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold tracking-tight mb-4">Maestros</h1>
      <Tabs defaultValue="personas">
        <TabsList>
          <TabsTrigger value="personas">Personas</TabsTrigger>
          <TabsTrigger value="empresas">Empresas</TabsTrigger>
          <TabsTrigger value="tags">Tags</TabsTrigger>
        </TabsList>
        <TabsContent value="personas"><PersonasMaster /></TabsContent>
        <TabsContent value="empresas"><EmpresasMaster /></TabsContent>
        <TabsContent value="tags"><TagsMaster /></TabsContent>
      </Tabs>
    </div>
  );
}

function PersonasMaster() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["personas"], queryFn: () => listPersonas() });
  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const [id, setId] = useState("");
  const [nombre, setNombre] = useState("");

  const m = useMutation({
    mutationFn: (vars: { id: number; nombre: string }) =>
      upsertPersona({ data: { ...vars, activo: true } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["personas"] });
      setId("");
      setNombre("");
      toast.success("Guardado");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  return (
    <div className="space-y-4 mt-4">
      <table className="w-full text-sm border border-border rounded-md overflow-hidden bg-card">
        <thead className="bg-muted/40">
          <tr>
            <th className="text-left px-3 py-2 w-20">Código</th>
            <th className="text-left px-3 py-2">Nombre</th>
            <th className="text-left px-3 py-2 w-24">Estado</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((p) => (
            <tr key={p.id} className="border-t">
              <td className="px-3 py-2 font-mono">{String(p.id).padStart(2, "0")}</td>
              <td className="px-3 py-2">{p.nombre}</td>
              <td className="px-3 py-2">
                <span className={p.activo ? "text-success" : "text-muted-foreground"}>
                  {p.activo ? "Activa" : "Inactiva"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {me?.isDireccion && (
        <div className="flex items-end gap-2 p-3 bg-card border border-border rounded-md">
          <div className="w-24">
            <label className="text-xs text-muted-foreground">Código</label>
            <Input type="number" value={id} onChange={(e) => setId(e.target.value)} className="h-8" />
          </div>
          <div className="flex-1">
            <label className="text-xs text-muted-foreground">Nombre</label>
            <Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="h-8" />
          </div>
          <Button
            size="sm"
            onClick={() => id && nombre && m.mutate({ id: Number(id), nombre })}
            className="gap-1"
          >
            <Plus className="w-4 h-4" /> Añadir / actualizar
          </Button>
        </div>
      )}
    </div>
  );
}

function EmpresasMaster() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["empresas"], queryFn: () => listEmpresas() });
  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const [codigo, setCodigo] = useState("");
  const [nombre, setNombre] = useState("");

  const m = useMutation({
    mutationFn: (vars: { codigo: string; nombre: string }) => createEmpresa({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["empresas"] });
      setCodigo("");
      setNombre("");
      toast.success("Creada");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  return (
    <div className="space-y-4 mt-4">
      <table className="w-full text-sm border border-border rounded-md overflow-hidden bg-card">
        <thead className="bg-muted/40">
          <tr><th className="text-left px-3 py-2 w-24">Código</th><th className="text-left px-3 py-2">Nombre</th></tr>
        </thead>
        <tbody>
          {data?.map((e) => (
            <tr key={e.id} className="border-t">
              <td className="px-3 py-2 font-mono">{e.codigo}</td>
              <td className="px-3 py-2">{e.nombre}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {me?.isDireccion && (
        <div className="flex items-end gap-2 p-3 bg-card border border-border rounded-md">
          <div className="w-32"><label className="text-xs text-muted-foreground">Código</label>
            <Input value={codigo} onChange={(e) => setCodigo(e.target.value)} className="h-8" /></div>
          <div className="flex-1"><label className="text-xs text-muted-foreground">Nombre</label>
            <Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="h-8" /></div>
          <Button size="sm" onClick={() => codigo && nombre && m.mutate({ codigo, nombre })} className="gap-1">
            <Plus className="w-4 h-4" /> Añadir
          </Button>
        </div>
      )}
    </div>
  );
}

function TagsMaster() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["tags"], queryFn: () => listTags() });
  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const [nombre, setNombre] = useState("");

  const create = useMutation({
    mutationFn: () => createTag({ data: { nombre } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["tags"] }); setNombre(""); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });
  const del = useMutation({
    mutationFn: (id: string) => deleteTag({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tags"] }),
  });

  return (
    <div className="space-y-4 mt-4">
      <div className="flex flex-wrap gap-2">
        {data?.map((t) => (
          <div key={t.id} className="inline-flex items-center gap-1 px-2 py-1 rounded bg-muted text-sm">
            {t.nombre}
            {me?.isDireccion && (
              <button onClick={() => del.mutate(t.id)} className="text-muted-foreground hover:text-destructive">
                <Trash2 className="w-3 h-3" />
              </button>
            )}
          </div>
        ))}
        {data && data.length === 0 && <p className="text-sm text-muted-foreground">Sin tags definidos.</p>}
      </div>
      {me?.isDireccion && (
        <div className="flex items-end gap-2 p-3 bg-card border border-border rounded-md">
          <div className="flex-1"><label className="text-xs text-muted-foreground">Nuevo tag</label>
            <Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="h-8" /></div>
          <Button size="sm" onClick={() => nombre && create.mutate()} className="gap-1">
            <Plus className="w-4 h-4" /> Crear
          </Button>
        </div>
      )}
    </div>
  );
}
