import { createFileRoute } from "@tanstack/react-router";
import { LicitacionFicha } from "@/components/leticia/licitacion-ficha";

export const Route = createFileRoute("/_authenticated/preparar/$id")({
  component: () => {
    const { id } = Route.useParams();
    return <LicitacionFicha id={id} bandeja="P" basePath="/preparar" />;
  },
});
