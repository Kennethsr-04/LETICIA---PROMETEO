import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BandejaPage } from "@/components/leticia/bandeja-page";
import { listLicitaciones, transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { AsignarPersonaSubmenu } from "@/components/leticia/asignar-persona-popover";
import { DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { RevisionRapida } from "@/components/leticia/revision-rapida";
import type { Licitacion } from "@/lib/leticia/types";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/recibidas/")({
  component: RecibidasPage,
});

function RecibidasPage() {
  const qc = useQueryClient();
  const [reviewOpen, setReviewOpen] = useState(false);

  const transition = useMutation({
    mutationFn: (vars: { id: string; action: "descartar_R" }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
  });

  // Pre-fetch for the review modal
  const reviewList = useQuery({
    queryKey: ["recibidas-for-review"],
    queryFn: () =>
      listLicitaciones({
        data: {
          bandeja: "R",
          estadosWorkflow: ["pendiente"],
          etapas: ["licitacion"],
          orderBy: "fecha_limite",
          orderDir: "asc",
        },
      }),
    enabled: reviewOpen,
  });

  return (
    <>
      <BandejaPage
        bandeja="R"
        titulo="Recibidas"
        basePath="/recibidas"
        columns={["id", "fecha", "organismo", "descripcion", "importe", "cpvs", "enlace"]}
        filtroEstadoOptions={[
          { value: "pendiente", label: "Recibidas", estados: ["pendiente"] },
          { value: "descartadas", label: "Descartadas", estados: ["descartada_manual", "descartada_auto"] },
        ]}
        filtroEtapaOptions={[
          { value: "licitacion", label: "Licitación", etapas: ["licitacion"] },
          { value: "previo", label: "Previo", etapas: ["previo"] },
        ]}
        onReview={() => setReviewOpen(true)}
        rowActions={(row: Licitacion) => (
          <>
            <AsignarPersonaSubmenu
              licitacionId={row.id}
              current={row.asignado_persona_id}
            />
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => transition.mutate({ id: row.id, action: "descartar_R" })}
              className="text-destructive"
            >
              Descartar
            </DropdownMenuItem>
          </>
        )}
      />
      {reviewOpen && (
        <RevisionRapida
          rows={(reviewList.data ?? []) as unknown as Licitacion[]}
          onClose={() => setReviewOpen(false)}
        />
      )}
    </>
  );
}
