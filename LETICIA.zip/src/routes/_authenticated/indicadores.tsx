import { createFileRoute } from "@tanstack/react-router";
import { BarChart3 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/indicadores")({
  component: IndicadoresPage,
});

function IndicadoresPage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-xl font-bold tracking-tight mb-1">Indicadores</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Cuadro de mandos. Disponible en próxima fase.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {["Volumen mensual", "Tasa de adjudicación", "Importe pipeline", "Tiempo medio en cada bandeja", "Reparto por persona", "Top organismos"].map((t) => (
          <div key={t} className="border border-dashed border-border rounded-md p-6 bg-card/60 flex flex-col items-center justify-center text-center min-h-40">
            <BarChart3 className="w-6 h-6 text-muted-foreground mb-2" />
            <div className="text-sm font-medium">{t}</div>
            <div className="text-[10px] text-muted-foreground mt-1 uppercase tracking-wide">próximamente</div>
          </div>
        ))}
      </div>
    </div>
  );
}
