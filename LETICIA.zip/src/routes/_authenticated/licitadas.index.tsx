import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { BandejaPage } from "@/components/leticia/bandeja-page";
import { transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";
import type { Licitacion } from "@/lib/leticia/types";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/licitadas/")({
  component: LicitadasPage,
});

function LicitadasPage() {
  const qc = useQueryClient();
  const transition = useMutation({
    mutationFn: (vars: { id: string; action: "marcar_ganada" | "marcar_perdida" }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
  });

  return (
    <BandejaPage
      bandeja="L"
      titulo="Licitadas"
      basePath="/licitadas"
      columns={["id", "fecha", "interes", "persona", "empresa", "organismo", "descripcion", "importe", "estado", "enlace"]}
      filtroEstadoOptions={[
        { value: "presentadas", label: "Presentadas", estados: ["presentada"] },
        { value: "ganadas", label: "Ganadas", estados: ["ganada"] },
        { value: "perdidas", label: "Perdidas", estados: ["perdida"] },
        { value: "todas", label: "Todas", estados: ["presentada", "ganada", "perdida"] },
      ]}
      rowActions={(row: Licitacion) => (
        <>
          <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "marcar_ganada" })}>
            Marcar Ganada
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "marcar_perdida" })}>
            Marcar Perdida
          </DropdownMenuItem>
        </>
      )}
    />
  );
}
