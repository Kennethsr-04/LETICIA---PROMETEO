import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { BandejaPage } from "@/components/leticia/bandeja-page";
import { transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import type { Licitacion } from "@/lib/leticia/types";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/evaluar/")({
  component: EvaluarPage,
});

function EvaluarPage() {
  const qc = useQueryClient();
  const transition = useMutation({
    mutationFn: (vars: { id: string; action: "descartar_E" | "marcar_evaluada" | "desmarcar_evaluada" | "pasar_a_preparar" }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
  });

  return (
    <BandejaPage
      bandeja="E"
      titulo="Evaluar"
      basePath="/evaluar"
      columns={["id", "fecha", "hora", "interes", "persona", "empresa", "organismo", "descripcion", "importe", "evaluada", "cpvs", "enlace"]}
      filtroEstadoOptions={[
        { value: "abiertas", label: "Pendientes + Evaluadas", estados: ["pendiente", "evaluada"] },
        { value: "pendientes", label: "Pendientes", estados: ["pendiente"] },
        { value: "evaluadas", label: "Evaluadas", estados: ["evaluada"] },
        { value: "descartadas", label: "Descartadas", estados: ["descartada"] },
      ]}
      rowActions={(row: Licitacion) => (
        <>
          {!row.evaluada ? (
            <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "marcar_evaluada" })}>
              Marcar evaluada
            </DropdownMenuItem>
          ) : (
            <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "desmarcar_evaluada" })}>
              Desmarcar evaluada
            </DropdownMenuItem>
          )}
          <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "pasar_a_preparar" })}>
            Pasar a Preparar →
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={() => transition.mutate({ id: row.id, action: "descartar_E" })}
            className="text-destructive"
          >
            Descartar
          </DropdownMenuItem>
        </>
      )}
    />
  );
}
