import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { BandejaPage } from "@/components/leticia/bandeja-page";
import { transitionLicitacion } from "@/lib/leticia/licitaciones.functions";
import { DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import type { Licitacion } from "@/lib/leticia/types";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/preparar/")({
  component: PrepararPage,
});

function PrepararPage() {
  const qc = useQueryClient();
  const transition = useMutation({
    mutationFn: (vars: { id: string; action: "descartar_P" | "pasar_a_licitada" }) =>
      transitionLicitacion({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
      toast.success("Actualizado");
    },
  });

  return (
    <BandejaPage
      bandeja="P"
      titulo="Preparar"
      basePath="/preparar"
      columns={["id", "fecha", "hora", "interes", "persona", "empresa", "organismo", "descripcion", "importe", "cpvs", "enlace"]}
      filtroEstadoOptions={[
        { value: "preparar", label: "Preparar", estados: ["preparar"] },
        { value: "descartadas", label: "Descartadas", estados: ["descartada"] },
      ]}
      rowActions={(row: Licitacion) => (
        <>
          <DropdownMenuItem onClick={() => transition.mutate({ id: row.id, action: "pasar_a_licitada" })}>
            Pasar a Licitada →
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={() => transition.mutate({ id: row.id, action: "descartar_P" })}
            className="text-destructive"
          >
            Descartar
          </DropdownMenuItem>
        </>
      )}
    />
  );
}
