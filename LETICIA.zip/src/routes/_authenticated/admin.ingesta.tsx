import { createFileRoute, redirect } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Upload, FileSpreadsheet, AlertCircle, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { getMyProfile } from "@/lib/leticia/maestros.functions";
import { ingestExcelGestboes, listIngestas } from "@/lib/leticia/ingesta.functions";
import { formatFechaHora } from "@/lib/leticia/format";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/ingesta")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
    const me = await getMyProfile();
    if (!me.isDireccion) throw redirect({ to: "/recibidas" });
  },
  component: IngestaPage,
});

function IngestaPage() {
  const qc = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const { data: ingestas } = useQuery({
    queryKey: ["ingestas"],
    queryFn: () => listIngestas(),
  });

  const m = useMutation({
    mutationFn: async (file: File) => {
      const buf = await file.arrayBuffer();
      const bytes = new Uint8Array(buf);
      // Convert to base64 in chunks
      let bin = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk) as unknown as number[]);
      }
      const base64 = btoa(bin);
      return ingestExcelGestboes({ data: { filename: file.name, base64 } });
    },
    onSuccess: (r) => {
      toast.success(`${r.nuevas} nuevas, ${r.actualizadas} actualizadas, ${r.anuncios} anuncios`);
      qc.invalidateQueries({ queryKey: ["ingestas"] });
      qc.invalidateQueries({ queryKey: ["licitaciones"] });
      qc.invalidateQueries({ queryKey: ["bandeja-counts"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Error"),
  });

  const handleFile = (f: File | null) => {
    if (!f) return;
    if (!/\.(xlsx|xls|xml)$/i.test(f.name)) {
      toast.error("Sube un fichero .xlsx, .xls o .xml");
      return;
    }
    m.mutate(f);
  };

  return (
    <div className="p-4 max-w-5xl mx-auto space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Ingesta Gestboes</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Sube el XML/Excel diario de Gestboes para crear o actualizar las licitaciones automáticamente.
        </p>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFile(e.dataTransfer.files[0] ?? null);
        }}
        onClick={() => inputRef.current?.click()}
        className={`border-2 border-dashed rounded-lg p-10 text-center cursor-pointer transition-colors ${
          dragOver ? "border-primary bg-primary/5" : "border-border bg-card hover:bg-muted/30"
        }`}
      >
        <Upload className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
        <p className="font-medium">Arrastra el fichero aquí, o haz clic para seleccionar</p>
        <p className="text-xs text-muted-foreground mt-1">.xlsx, .xls o .xml</p>
        <input
          ref={inputRef}
          type="file"
          accept=".xlsx,.xls,.xml"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
        />
        {m.isPending && (
          <p className="text-sm text-primary mt-3 animate-pulse">Procesando…</p>
        )}
      </div>

      <div className="bg-card border border-border rounded-md">
        <div className="px-4 py-2 border-b text-sm font-semibold flex items-center gap-2">
          <FileSpreadsheet className="w-4 h-4" />
          Historial de ingestas
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left px-3 py-2">Fichero</th>
                <th className="text-left px-3 py-2 w-40">Fecha</th>
                <th className="text-right px-3 py-2 w-20">Filas</th>
                <th className="text-right px-3 py-2 w-20">Nuevas</th>
                <th className="text-right px-3 py-2 w-24">Actualizadas</th>
                <th className="text-right px-3 py-2 w-20">Anuncios</th>
                <th className="text-center px-3 py-2 w-20">Errores</th>
              </tr>
            </thead>
            <tbody>
              {ingestas?.map((i) => (
                <tr key={i.id} className="border-t">
                  <td className="px-3 py-2 font-mono text-xs">{i.filename}</td>
                  <td className="px-3 py-2 text-xs">{formatFechaHora(i.uploaded_at)}</td>
                  <td className="px-3 py-2 text-right font-mono">{i.total_filas}</td>
                  <td className="px-3 py-2 text-right font-mono text-success">{i.nuevas_licitaciones}</td>
                  <td className="px-3 py-2 text-right font-mono">{i.licitaciones_actualizadas}</td>
                  <td className="px-3 py-2 text-right font-mono">{i.anuncios_anadidos}</td>
                  <td className="px-3 py-2 text-center">
                    {i.errores ? (
                      <span className="inline-flex items-center gap-1 text-warning text-xs">
                        <AlertCircle className="w-3 h-3" />
                        {Array.isArray(i.errores) ? i.errores.length : "?"}
                      </span>
                    ) : (
                      <Check className="w-3.5 h-3.5 inline text-success" />
                    )}
                  </td>
                </tr>
              ))}
              {(!ingestas || ingestas.length === 0) && (
                <tr>
                  <td colSpan={7} className="text-center text-muted-foreground py-6 text-xs">
                    Sin ingestas todavía.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
