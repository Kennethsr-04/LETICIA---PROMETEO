import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyProfile } from "@/lib/leticia/maestros.functions";
import { listUsuarios, setDireccionRole } from "@/lib/leticia/usuarios.functions";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/usuarios")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
    const me = await getMyProfile();
    if (!me.isDireccion) throw redirect({ to: "/recibidas" });
  },
  component: UsuariosPage,
  errorComponent: ({ error }) => (
    <div className="p-4 text-sm text-destructive">Error: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-4">No encontrado.</div>,
});

function UsuariosPage() {
  const qc = useQueryClient();
  const list = useServerFn(listUsuarios);
  const setRole = useServerFn(setDireccionRole);
  const [q, setQ] = useState("");

  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const { data, isLoading } = useQuery({
    queryKey: ["admin-usuarios"],
    queryFn: () => list(),
  });

  const mut = useMutation({
    mutationFn: (vars: { userId: string; enable: boolean }) => setRole({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-usuarios"] });
      toast.success("Rol actualizado");
    },
    onError: (e: any) => toast.error(e?.message ?? "Error al actualizar rol"),
  });

  const filtered = useMemo(() => {
    if (!data) return [];
    const needle = q.trim().toLowerCase();
    if (!needle) return data;
    return data.filter(
      (u) =>
        u.nombre.toLowerCase().includes(needle) ||
        u.email.toLowerCase().includes(needle),
    );
  }, [data, q]);

  return (
    <div className="p-4 max-w-5xl mx-auto space-y-4">
      <div className="flex items-center gap-2">
        <Link to="/admin" className="text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <h1 className="text-xl font-bold tracking-tight">Gestión de Usuarios</h1>
      </div>

      <p className="text-sm text-muted-foreground">
        Activa el rol <strong>Dirección</strong> para dar acceso a Administración e Ingesta
        Gestboes. Todos los usuarios tienen siempre el rol Comercial.
      </p>

      <Input
        placeholder="Buscar por nombre o email…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        className="max-w-sm"
      />

      <div className="border border-border rounded-md bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Nombre</th>
              <th className="text-left px-3 py-2">Email</th>
              <th className="text-left px-3 py-2">Cód. persona</th>
              <th className="text-left px-3 py-2">Roles</th>
              <th className="text-right px-3 py-2">Dirección</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={5} className="px-3 py-6 text-center text-muted-foreground">Cargando…</td></tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr><td colSpan={5} className="px-3 py-6 text-center text-muted-foreground">Sin resultados</td></tr>
            )}
            {filtered.map((u) => {
              const isSelf = me?.profile?.id === u.id;
              return (
                <tr key={u.id} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    {u.nombre}
                    {isSelf && <span className="ml-2 text-[10px] text-muted-foreground">(tú)</span>}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">{u.email}</td>
                  <td className="px-3 py-2 font-mono text-xs">{u.codigo_persona ?? "—"}</td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1 flex-wrap">
                      {u.roles.map((r) => (
                        <span key={r} className="text-[10px] px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground font-mono">
                          {r}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-3 py-2 text-right">
                    <Switch
                      checked={u.isDireccion}
                      disabled={mut.isPending || (isSelf && u.isDireccion)}
                      onCheckedChange={(checked) =>
                        mut.mutate({ userId: u.id, enable: checked })
                      }
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
