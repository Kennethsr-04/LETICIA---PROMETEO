
# Sprint 1 — Leticia

App de gestión del ciclo de vida de licitaciones, ingesta desde Excel/XML de Gestboes (subida manual), auth con roles Dirección/Comercial, 4 bandejas R/E/P/L con tabla + ficha + filtros + acciones, modo Revisión rápida con teclado, y reglas automáticas de clasificación y descarte.

## 1. Stack y backend

- TanStack Start + Tailwind + shadcn/ui (ya en plantilla).
- **Lovable Cloud** habilitado (Postgres + Auth + Storage).
- Auth: email + contraseña. Roles en tabla `user_roles` (`direccion`, `comercial`) con función `has_role` (security definer). RLS scoped por persona; `direccion` ve todo.
- Servidor: `createServerFn` para ingesta, mutaciones y queries pesadas. Loaders públicos prohibidos sobre datos protegidos.

## 2. Modelo de datos

```text
profiles            (id=auth.users.id, nombre, codigo_persona int [0,5,6,7,8...], activo)
user_roles          (user_id, role enum: 'direccion'|'comercial')
personas            -- maestro: 0-Moises, 5-Marta, 6-Santiago, 7-Carmen, 8-Adriana
empresas            -- maestro (P, B, N)
tags                -- maestro
cpvs                (codigo pk, descripcion)  -- maestro CPVs

licitaciones        -- PADRE (clave lógica: expediente + codigo_gestboes)
  id, expediente, codigo_gestboes UNIQUE (expediente, codigo_gestboes)
  descripcion, contrato, forma_adjudicacion
  importe_euros, organismo, administracion
  provincia, autonomia, poblacion
  plazo_meses, prorroga_anios
  fecha_limite (timestamptz), fecha_orientativa
  enlace_anuncio, enlace_secundario
  etapa enum('previo','licitacion','evaluacion','cancelada')      -- recalculada por última comunicación
  bandeja enum('R','E','P','L')                                    -- estado del workflow
  estado_workflow enum:
    R: 'pendiente'|'descartada_manual'|'descartada_auto'
    E: 'pendiente'|'evaluada'|'descartada'
    P: 'preparar'|'descartada'
    L: 'presentada'|'ganada'|'perdida'
  asignado_persona_id, empresa_id, interes int (1-9), evaluada bool
  comentarios_evaluacion text
  descartada bool, motivo_descarte
  created_at, updated_at

licitacion_cpvs        (licitacion_id, cpv_codigo)
licitacion_tags        (licitacion_id, tag_id)

anuncios               -- HIJOS: cada fila del Excel/XML
  id, licitacion_id, fecha_publicacion, etapa, estado_raw
  raw_jsonb (fila original completa)
  importe_euros, descripcion, organismo, enlace_anuncio
  fecha_limite, fecha_orientativa, forma_adjudicacion
  created_at

ingestas               -- 1 por fichero subido
  id, filename, uploaded_by, uploaded_at,
  total_filas, nuevas_licitaciones, anuncios_anadidos, errores jsonb
```

Todas las tablas `public.*` con `GRANT` a `authenticated` + `service_role`, RLS activa. Política por persona asignada (`comercial` ve solo `asignado_persona_id = su persona`); `direccion` ve todo vía `has_role`.

## 3. Ingesta del Excel Gestboes

Columnas confirmadas del fichero subido (`20260319_C.XLSX`, hoja `Hoja1`):
`Código, Tema, Estado, Fecha, Descripción, Expediente, Contrato, Forma de adjudicación, Importe en Euros, Variantes, Garantía, Licitación, Plazo Ejecución, Clasificación, Organismo, Administración, Publicación, Población, Provincia, Autonomía, Información, Info. Presentación, Info. Apertura, Fecha Límite de Pesent., Fecha Orientativa Gestboes., Fecha Apertura, Observaciones, Web Publicación, Cod.Tema, Enlace Anuncio, CPV`

**Flujo (server fn `ingestExcelGestboes`):**
1. Pantalla `Administración → Ingesta` (drag&drop .xlsx/.xml). Sólo `direccion`.
2. Parseo con `xlsx` (SheetJS) en servidor.
3. Para cada fila:
   - Clave de match: `(expediente, codigo_gestboes)` con coincidencia 100% simultánea.
   - Si **no existe** licitación → crear licitación + primer anuncio.
   - Si **existe** → crear nuevo anuncio + actualizar campos de la licitación (último valor recibido).
4. **Clasificación de Etapa** (poco restrictiva, prefiere Licitación):
   - `cancelada`: `Estado` contiene "desist", "cancel", "anulad".
   - `evaluacion`: `fecha_limite < hoy` y la licitación ya existía previamente.
   - `previo`: `Forma de adjudicación` contiene "previo/previa" **Y** (`Fecha Orientativa` vacía **Y** `Fecha Límite` vacía). Si dudas → `licitacion`.
   - Resto → `licitacion`.
5. **Reclasificación de bandeja** por evento:
   - Nueva licitación → bandeja `R`, estado `pendiente`.
   - Anuncio con etapa `cancelada` sobre licitación existente → marca licitación como `descartada` (en su bandeja actual) con `motivo_descarte='cancelada_gestboes'`.
6. Parsing auxiliar:
   - `fecha_limite`: regex sobre `Fecha Límite de Pesent.` → `dd/mm/yyyy hh:mm`.
   - `plazo_meses`: extraer número de `Plazo Ejecución`.
   - `prorroga_anios`: extraer de `Observaciones`/`Licitación`.
   - `CPV`: split y upsert en `cpvs` + `licitacion_cpvs`.
7. Devuelve resumen `{nuevas, actualizadas, anuncios, errores}` y lo guarda en `ingestas`.

## 4. Reglas automáticas (job + on-read)

- **Descarte auto en R**: licitación en bandeja `R` con `fecha_limite < hoy` → `estado_workflow='descartada_auto'`.
- **Descarte auto en E**: licitación en `E/pendiente` con `fecha_limite < hoy` → `descartada en segunda`.
- **Asignación**: al asignar persona en `R`, pasa automáticamente a `E/pendiente`.
- **Cancelada en cualquier fase**: marca descartada.

Implementación: server fn `runAutoRules()` ejecutado (a) tras cada ingesta y (b) al abrir cada bandeja (idempotente, barato).

## 5. UI — Layout

- Sidebar shadcn colapsable con: **R** Recibidas · **E** Evaluar · **P** Preparar · **L** Licitadas · **I** Indicadores (placeholder) · **C** Maestros · **A** Administración.
- Header con usuario, rol, logout.
- Rutas:
  - `/_authenticated/recibidas` (+ `/recibidas/$id`)
  - `/_authenticated/evaluar` (+ `/evaluar/$id`)
  - `/_authenticated/preparar` (+ `/preparar/$id`)
  - `/_authenticated/licitadas` (+ `/licitadas/$id`)
  - `/_authenticated/maestros` (personas, empresas, tags, cpvs)
  - `/_authenticated/admin/ingesta`
  - `/_authenticated/indicadores` (placeholder)
  - `/auth` (login)

## 6. Bandejas (común)

Cada bandeja = componente `<BandejaTabla>` con barra de acciones:
- Buscador full-text (contiene, todos los campos relevantes vía `ilike` sobre vista `licitaciones_search`).
- Filtros específicos (ver abajo).
- Rango de fechas (límite).
- Orden por cabecera (todas las columnas).
- Selección y acciones de fila.
- Botón **Revisión rápida** (sólo en R).

### Recibidas (R)
- Columnas: ID · Fecha · Organismo · Descripción (3 líneas) · Importe · CPVs (3 líneas) · `+` enlace.
- Filtros barra: `Recibidas | Descartadas` (default Recibidas) · `En Licitación | Previo` (default Licitación) · rango fechas.
- Acciones fila: asignar persona (popover), descartar.
- Orden por defecto: fecha ascendente.

### Evaluar (E)
- Columnas: ID · Fecha · Hora · Interés · Persona · Empresa · Organismo · Descripción · Importe · Evaluada · CPVs · `+` · acciones.
- Filtros: `Pendientes | Evaluadas | Descartadas` (default Pendientes+Evaluadas) · rango fechas · Interés (multi) · Empresa · Persona (comercial = sólo su código; Moises ve todos) · Importe desde/hasta · Tags (multi).
- Acciones: descartar · marcar evaluada · pasar a Preparar.

### Preparar (P)
- Columnas como Evaluar.
- Filtros: `Preparar | Descartadas` (default Preparar).
- Acciones: descartar · pasar a Licitadas.

### Licitadas (L)
- Filtros: `Presentadas | Ganadas | Perdidas`.
- Acciones (en ficha): marcar Ganada / Perdida.

## 7. Ficha de licitación

Componente `<LicitacionFicha>` adaptable por bandeja:

- **Cabecera** (una fila): ID · Fecha+Hora límite · Etapa · Descarte · Interés (1-9) · Empresa · Tags (sólo E/P/L) · iconos Enlace principal + secundario.
- **Datos principales** (3 columnas):
  - Col izq: Código Gestboes, Expediente, Descripción, Contrato, Importe €, Organismo, Provincia/Autonomía, Plazo (meses), Prórroga (años), Forma de adjudicación, Comentarios (memo, E/P/L).
  - Col dcha: tabla CPVs (código + descripción).
- **Anuncios publicados**: tabla de todos los `anuncios` ligados (fecha, etapa, expediente, descripción, organismo, importe, "Ver" → modal con la fila completa).
- Barra de acciones: `< anterior`, `siguiente >` (flechas izq/dcha), botón principal por bandeja (Asignar / Pasar a Preparar / Pasar a Licitada / Marcar Ganada-Perdida), Descartar.
- Edición inline en campos editables (asignación restringida a Moises o `direccion`).

## 8. Modo Revisión rápida (Recibidas)

Pop-up a pantalla completa con 3 fichas reducidas apiladas:
- Superior (gris claro): ya revisada.
- Centro (blanco): activa.
- Inferior (gris): siguiente.

Ficha reducida: Descripción (preview 256 chars + "ver más"), Importe, Fecha, Organismo, CPVs (código + nombre), Descarte, Asignación.

Atajos teclado:
- `↑` / `↓`: navegar.
- `n`: marca `descarte = NO`. `n + Enter`: descarta y avanza.
- `0|5|6|7|8`: asigna persona (sale automáticamente de R, va a E). `<num> + Enter`: asigna y avanza.
- `Esc`: salir.

Cada acción es una mutación atómica `useMutation` con `onSuccess` que invalida la query de la bandeja → reclasificación visible. Latencia objetivo < 200 ms (optimistic update).

## 9. Maestros (C)

CRUD simple (tabla + drawer de edición) para: Personas, Empresas, Tags, CPVs. Sólo `direccion` edita; todos leen.

## 10. Administración (A)

- Subida de fichero Gestboes (xlsx/xml) + historial de `ingestas` con resumen y errores.
- Gestión de usuarios (asignar rol y `codigo_persona`).

## 11. Indicadores (I)

Placeholder con tarjetas vacías "Disponible en próxima fase".

---

## Detalles técnicos

- **Server functions** en `src/lib/*.functions.ts` (ingesta, mutaciones, queries). Cliente admin Supabase sólo dentro de handlers (`await import('@/integrations/supabase/client.server')`) cuando hace falta (creación de usuarios).
- **Auth middleware** `requireSupabaseAuth` en toda mutación; `attachSupabaseAuth` en `src/start.ts`.
- **Layout protegido** managed `_authenticated/route.tsx`.
- **TanStack Query** para data; `queryOptions` por bandeja parametrizadas por filtros.
- **Parseo Excel**: dependencia `xlsx` (SheetJS) — fully bundled, compatible Workers.
- **Indices DB**: `(expediente, codigo_gestboes)` unique, `(bandeja, estado_workflow)`, `(asignado_persona_id)`, `(fecha_limite)`, GIN trigram sobre descripción/organismo para búsqueda full-text.
- **Login social**: por defecto no se añade (sólo email/password, dado el carácter interno). Si lo quieres añadimos Google después.

## Lo que NO entra en este sprint
- Cuadro de mandos (Indicadores) — sólo placeholder.
- Ingesta automática por correo o carpeta cloud (parser preparado para reutilizar).
- IA / prompts de análisis de pliegos.
- Bloqueo HIBP de contraseñas (se puede activar tras el sprint).
